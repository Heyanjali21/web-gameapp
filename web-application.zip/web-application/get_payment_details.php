<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$apiUrl = 'https://disawar.techwarezen.shop/admin/api-get-user-payment-details';

$chOtp = curl_init('https://disawar.techwarezen.shop/admin/api-validate-bank');
curl_setopt($chOtp, CURLOPT_RETURNTRANSFER, true);
$requestBodyOtp = json_encode([
    'env_type' => 'Prod',
    'app_key' => 'HbegvJLeKwSFyApopniGHHBTZPocyH',
    'unique_token' => isset($_COOKIE['localDataStore']) ? $_COOKIE['localDataStore'] : '',
]);

    curl_setopt($chOtp, CURLOPT_POSTFIELDS, $requestBodyOtp);

    // Execute the first API call
    $responseOtp = curl_exec($chOtp);

    if (curl_errno($chOtp)) {
        echo 'Curl error for OTP API: ' . curl_error($chOtp) . ' (' . curl_errno($chOtp) . ')';
    } else {
        if (!empty($responseOtp)) {
            $jsonStartOtp = strpos($responseOtp, '{');

            if ($jsonStartOtp !== false) {
                $jsonStringOtp = substr($responseOtp, $jsonStartOtp);
                $dataOtp = json_decode($jsonStringOtp, true);
                echo json_encode(['debug_response_otp' => $dataOtp]);

                if (isset($dataOtp["otp"]) && !empty($dataOtp["otp"])) {
                    $otp = $dataOtp["otp"];
                    echo "OTP: $otp";

                    // Continue with the second API call (getting user payment details)
                    $chPaymentDetails = curl_init($apiUrl);
                    curl_setopt($chPaymentDetails, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($chPaymentDetails, CURLOPT_POST, 1);
                    curl_setopt($chPaymentDetails, CURLOPT_POSTFIELDS, $requestBodyOtp);
                    curl_setopt($chPaymentDetails, CURLOPT_TIMEOUT, 10);
                    $headersPaymentDetails = [
                        'Content-Type: application/json',
                    ];
                    curl_setopt($chPaymentDetails, CURLOPT_HTTPHEADER, $headersPaymentDetails);

                    $responsePaymentDetails = curl_exec($chPaymentDetails);

                    // Check for cURL errors for the second API call
                    if (curl_errno($chPaymentDetails)) {
                        echo 'Curl error for payment details API: ' . curl_error($chPaymentDetails) . ' (' . curl_errno($chPaymentDetails) . ')';
                    } else {
                        // Process the response for the second API call
                        if (!empty($responsePaymentDetails)) {
                            $jsonStartPaymentDetails = strpos($responsePaymentDetails, '{');

                            if ($jsonStartPaymentDetails !== false) {
                                $jsonStringPaymentDetails = substr($responsePaymentDetails, $jsonStartPaymentDetails);
                                $dataPaymentDetails = json_decode($jsonStringPaymentDetails, true);

                                // Debug: Print the entire decoded response for payment details API
                                echo json_encode(['debug_response_payment_details' => $dataPaymentDetails]);

                                // Check if "payment_details" key exists and is not empty
                                if (isset($dataPaymentDetails["payment_details"]) && !empty($dataPaymentDetails["payment_details"])) {
                                    $firstPaymentDetail = $dataPaymentDetails["payment_details"][0];
                                    if (isset($firstPaymentDetail['phone_pay_number'])) {
                                        echo $firstPaymentDetail['phone_pay_number'];
                                    } else {
                                        echo 'Error: Key "phone_pay_number" not found in the first element of "payment_details".';
                                    }
                                } else {
                                    echo 'Error: Key "payment_details" does not exist or is empty for payment details API.';
                                }
                            } else {
                                echo 'Error: Unable to find the start of the JSON response for payment details API.';
                            }
                        } else {
                            echo 'Empty response for payment details API';
                        }
                    }

                    curl_close($chPaymentDetails);
                } else {
                    echo 'Error: Key "otp" does not exist or is empty in the response for OTP API.';
                }
            } else {
                echo 'Error: Unable to find the start of the JSON response for OTP API.';
            }
        } else {
            echo 'Empty response for OTP API';
        }
    }

    curl_close($chOtp);
?>

<script>
        function goBack() {
            window.location.href = 'game.php';
        }
    </script>


   
     <!--for allow onlu one digit-->
    <script>
    function validateInput(input) {
        input.value = input.value.replace(/\D/g, '');
        if (input.value < 0) {
            input.value = '';
        }
    }
</script>

<!-- for radio button -->
 
<script>
    function handleOption(option) {
        const labelForAmount = document.getElementById("labelForAmount");
        const amountInput = document.getElementById("amount");

        if (option === 'open') {
            labelForAmount.textContent = 'Open Digit';
        } else if (option === 'close') {
            labelForAmount.textContent = 'Close Digit';
        }
        
    }
</script>

<!-- for disallow 0 or negative number -->

<script>
    document.getElementById("number").addEventListener("input", function () {
        let inputValue = parseInt(this.value);

        if (isNaN(inputValue) || inputValue < 10) {
            document.getElementById("error-message").textContent = "Please enter a number greater than or equal to 10.";
            this.setCustomValidity("Please enter a number greater than or equal to 10.");
        } else {
            document.getElementById("error-message").textContent = "";
            this.setCustomValidity("");
        }
    });
</script>

<script>
    function displayFormData() {
        const status = document.querySelector('input[name="status"]:checked');
        const amount = document.getElementById('amount').value;
        const points = document.getElementById('number').value;

        // Create a new row in the table
        const table = document.getElementById("dataTable");
        const row = table.insertRow(1); // Insert at the second row (index 1)
        const cell1 = row.insertCell(0);
        const cell2 = row.insertCell(1);
        const cell3 = row.insertCell(2);

        // Populate the cells with the entered data
        cell1.innerHTML = status ? status.value : "Not selected";
        cell2.innerHTML = amount;
        cell3.innerHTML = points;

        // Show the table
        table.style.display = "table";
        document.getElementById("showDataBtn").style.display = "block";
    }

    function validateAndSubmitForm() {
        const enteredValue = document.getElementById("amount").value;

        if (/^\d$/.test(enteredValue)) {
            document.getElementById("amountError").textContent = "";
            displayFormData();
        } else {
            document.getElementById("amountError").textContent = "Not a valid digit. Please enter a single digit.";
        }
    }
</script>


  <!--for suggestion digit-->

<script>
    function suggestDigits(value) {
        document.getElementById("suggestions").innerHTML = "";
        const allowedDigits = {
            "1": [
               1 , 2, 3, 4, 5, 6, 7, 8, 9],
            
        };

        // Check if the entered value is a valid single digit (1 to 9)
        if (value.length === 1 && Object.keys(allowedDigits).includes(value)) {
            let suggestionsList = allowedDigits[value];

            if (suggestionsList) {
                suggestionsList.forEach(suggestion => {
                    let suggestionElement = document.createElement("div");
                    suggestionElement.classList.add("suggestion");
                    suggestionElement.textContent = suggestion;
                    suggestionElement.addEventListener("click", function () {
                        document.getElementById("amount").value = suggestion;
                        document.getElementById("suggestions").innerHTML = "";
                    });

                    document.getElementById("suggestions").appendChild(suggestionElement);
                });
            }
        } 
    }
</script>

<script>
    function submitForm() {
        var closeDigit = document.getElementById('totalBids') ? document.getElementById('totalBids').textContent : '';
        var points = calculateTotalPoints(); 
        var gameType = document.getElementById('gameType') ? document.getElementById('gameType').textContent : '';
        window.location.href = 'show_result.php?closeDigit=' + closeDigit + '&points=' + points + '&status=' + gameType;
    }

    function calculateTotalPoints() {
        var sumTotalPoints = 0;

        var dataTable = document.getElementById('dataTable');
        if (dataTable) {
            var rows = dataTable.getElementsByTagName('tr');

            for (var i = 1; i < rows.length; i++) {
                var cells = rows[i].getElementsByTagName('td');
                var points = parseInt(cells[2].innerHTML);

                if (!isNaN(points)) {
                    sumTotalPoints += points;
                }
            }
        }

        return sumTotalPoints;
    }
</script>


</body>
</html>


<?php
// API endpoint
$api_url = 'https://disawar.techwarezen.shop/admin/api-user-wallet-balance';

$uniqueToken = isset($_COOKIE['localDataStore']) ? $_COOKIE['localDataStore'] : '';
// JSON payload
$data = array(
    "env_type" => "Prod",
    "app_key" => "HbegvJLeKwSFyApopniGHHBTZPocyH",
    "unique_token" => $uniqueToken,
);

// Convert the data to JSON format
$jsonData = json_encode($data);

// Create context options for the HTTP request
$options = array(
    'http' => array(
        'header' => "Content-type: application/json",
        'method' => 'POST',
        'content' => $jsonData,
    )
);

// Create a stream context for the request
$context = stream_context_create($options);

// Make the POST request to the API with the specified context
$response = file_get_contents($api_url, false, $context);

// Decode the JSON response
$data = json_decode($response, true);

// Check if the request was successful
if ($data['status'] === true) {
    // Display specific wallet details
    echo '<p>Minimum Withdrawal: ' . $data['min_withdrawal'] . '</p>';
    echo '<p>Maximum Withdrawal: ' . $data['max_withdrawal'] . '</p>';
    echo '<p>Minimum Transfer: ' . $data['min_transfer'] . '</p>';
    echo '<p>Maximum Transfer: ' . $data['max_transfer'] . '</p>';
    echo '<p>Withdrawal Open Time: ' . $data['withdraw_open_time'] . '</p>';
    echo '<p>Withdrawal Close Time: ' . $data['withdraw_close_time'] . '</p>';
} else {
    // Display an error message if the request was not successful
    echo 'Error: ' . $data['msg'];
}
?>

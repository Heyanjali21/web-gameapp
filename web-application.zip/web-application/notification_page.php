<?php include 'comman/notification_header.php';
?>
<div class="abc">
        <span class="back-icon" onclick="goBack()">&#8592;</span>
        <h2>Notification</h2>
    </div>
  </body>
  <div class="container">
    <div class="profile-container">
    <img src="https://disawar.techwarezen.shop/web-app/assets/img/notfound.png" alt="Profile Logo" class="profile-logo"><p style="color: black;">
                No result found
            </p>
      </div>
  </div>
  <?php include 'comman/contact_footer.php';
?>
<?php include 'comman/full_sangam_header.php';
?>
<div class="abc">
    <span class="back-icon" onclick="goBack()">&#8592;</span>
    <h2>Full Sangam</h2>
</div>
<div class="container">
    <div class="centered-content">
        <?php
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);

        $apiUrl = 'https://disawar.techwarezen.shop/admin/api-get-current-date';

        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $requestBody = json_encode([
            'env_type' => 'Prod',
            'app_key' => 'HbegvJLeKwSFyApopniGHHBTZPocyH',
            'unique_token' => isset($_COOKIE['localDataStore']) ? $_COOKIE['localDataStore'] : '',
            'game_id' => isset($_COOKIE['game_id']) ? $_COOKIE['game_id'] : '',
        ]);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $requestBody);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);

        $headers = [
            'Content-Type: application/json',
        ];
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Curl error: ' . curl_error($ch) . ' (' . curl_errno($ch) . ')';
        } else {
            if (empty($response)) {
                echo 'Empty response';
            } else {
                $jsonStart = strpos($response, '{');

                if ($jsonStart !== false) {
                    $jsonString = substr($response, $jsonStart);

                    $data = json_decode($jsonString, true);
                    if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
                        echo 'Error decoding JSON response: ' . json_last_error_msg();
                    } else {
                        if (isset($data['new_date'])) {
                            echo $data['new_date'];
                        } else {
                            echo 'Error: Key "new_date" not found in the response.';
                        }
                    }
                } else {
                    echo 'Error: Unable to find the start of the JSON response.';
                }
            }
        }

        curl_close($ch);
        ?>
    </div>

    <form class="con" id="myForm" onsubmit="event.preventDefault(); validateAndSubmitForm();">
    <div class="form-group">
        <label for="openAmount" id="openLabelForAmount">Open Pana</label>
        <input type="text" id="openAmount" name="openAmount" placeholder="Enter Digit" maxlength="3" oninput="suggestDigits('open', this.value)" required>
        <span id="openAmountError" style="color: red;"></span>
        <div id="openSuggestionsContainer">
            <div id="openSuggestions"></div>
        </div>
    </div>
    <div class="form-group">
        <label for="closeAmount" id="closeLabelForAmount">Close Pana</label>
        <input type="text" id="closeAmount" name="closeAmount" placeholder="Enter Digit" maxlength="3" oninput="suggestDigits('close', this.value)" required>
        <span id="closeAmountError" style="color: red;"></span>
        <div id="closeSuggestionsContainer">
            <div id="closeSuggestions"></div>
        </div>
    </div>

    <div class="form-group">
        <label for="number">Points</label>
        <input type="number" id="number" name="number" placeholder="Enter Points" required min="10">
        <span id="error-message" style="color: red;"></span>
    </div>

    <button type="button" class="button" onclick="validateAndSubmitForm()">PROCEED</button>

    <table id="dataTable" border="1" style="display:none;">
    <thead>
        <tr>
            <th>Open Pana</th>
            <th>Close Digit</th>
            <th>Points</th>
        </tr>
    </thead>
    <tbody id="dataBody"></tbody>
</table>

<button type="button" id="showDataBtn" style="display:none;" onclick="submitForm()">Submit</button>
  
</form>


<?php include 'comman/full_sangam_footer.php';
?>
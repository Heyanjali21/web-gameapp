<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$apiUrl = 'https://disawar.techwarezen.shop/admin/api-get-user-payment-details';

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$requestBody = json_encode([
    'env_type' => 'Prod',
    'app_key' => 'HbegvJLeKwSFyApopniGHHBTZPocyH',
    'unique_token' => isset($_COOKIE['localDataStore']) ? $_COOKIE['localDataStore'] : '',
]);

curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $requestBody);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
$headers = [
    'Content-Type: application/json',
];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);

if (curl_errno($ch)) {
    echo 'Curl error: ' . curl_error($ch) . ' (' . curl_errno($ch) . ')';
} else {
    if (empty($response)) {
        echo 'Empty response';
    } else {
        $jsonStart = strpos($response, '{');

        if ($jsonStart !== false) {
            $jsonString = substr($response, $jsonStart);
            $data = json_decode($jsonString, true);

            if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
                echo 'Error decoding JSON response: ' . json_last_error_msg();
            } else {
                echo json_encode(['debug_response' => $data]);
                if (isset($data["payment_details"]) && !empty($data["payment_details"])) {
                    $firstPaymentDetail = $data["payment_details"][0];
                    if (isset($firstPaymentDetail['phone_pay_number'])) {
                        echo $firstPaymentDetail['phone_pay_number'];
                    } else {
                        echo 'Error: Key "phone_pay_number" not found in the first element of "payment_details".';
                    }
                } else {
                    echo 'Error: Key "payment_details" does not exist or is empty.';
                }
            }
        } else {
            echo 'Error: Unable to find the start of the JSON response.';
        }
    }
}

curl_close($ch);
?>

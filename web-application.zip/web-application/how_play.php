<?php include 'comman/play_header.php';
?>
<div class="abc">
    <span class="back-icon" onclick="goBack()">&#8592;</span>
    <h2>How To Play</h2>
</div>
<div class="container">
    <div class="header">
        <div class="button-container">
            <button onclick="handleLeftButtonClick()" style="justify-content: center;">How To Play</button>
        </div>
        <?php
        $apiUrl = 'https://disawar.techwarezen.shop/admin/api-how-to-play';
        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $requestBody = json_encode([
            'env_type' => 'Prod',
            'app_key' => 'HbegvJLeKwSFyApopniGHHBTZPocyH',
            'unique_token' => '4AR6tSuQEquKeUL7Uwh1ZnkaJz0vrK'
        ]);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $requestBody);
        $headers = [
            'Content-Type: application/json',
        ];
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Curl error: ' . curl_error($ch);
        }
        curl_close($ch);
        $data = json_decode($response, true);
        if ($data !== null && isset($data['content'])) {
            // Display each set of data in a separate card
            foreach ($data['content'] as $contentItem) {
                $howToPlayContent = $contentItem['how_to_play_content'];
                $videoLink = $contentItem['video_link'];
        ?>
                <div class="card">
                    <div class="card-body">
                        <?php echo $howToPlayContent; ?>
                        <p><a href="<?php echo $videoLink; ?>" target="_blank">Video Link</a></p>
                    </div>
                </div>
        <?php
            }
        } else {
            echo 'Error decoding JSON response or content not available.';
        }
        ?>
    </div>
</div>
<?php include 'comman/contact_footer.php';
?>
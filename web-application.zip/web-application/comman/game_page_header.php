<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sgkalyan</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-qh8Xz5g+5+pru3AKbBxyTsvYZJTRs/46g2hghT8cF4vj84Qw4rcq5egxxjczD2hpjli4ItRVr7YqNJo6ikfCA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            overflow-x: hidden;
        }

        .container {
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border-radius: 0px;
            margin: auto;
            max-width: 400px;
            position: relative;
            text-align: center;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
        }

        .abc {
            background-color: #702424;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: auto;
            max-width: 400px;
            display: flex;
            align-items: center;
        }

        .back-icon {
            margin-right: 20px;
            cursor: pointer;
        }

        .card {
            border: 1px solid #ccc;
            border-radius: 8px;
            padding: 15px;
            margin: 10px;
            width: 30%;
        }

        .card img {
            max-width: 100%;
            max-height: 60px;
            object-fit: contain;
            border-radius: 60%;
            margin-bottom: 10px;
            background-color: #171616;
        }

        .cardd {
            border: 1px solid #ccc;
            border-radius: 20px;
            padding: 15px;
            margin: 10px;
            width: 80%;
        }

        .cardd img {
            max-width: 100%;
            max-height: 60px;
            object-fit: contain;
            border-radius: 60%;
            margin-bottom: 10px;
            background-color: #171616;
        }
    </style>
</head>

<body>
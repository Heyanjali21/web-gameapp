

<?php include 'comman/contact_header.php';
?>
<div class="abc">
    <span class="back-icon" onclick="goBack()">&#8592;</span>
    <h2>Contact Us</h2>
</div>
<div class="container">
    <div>
    <img src="https://apk.sportsfigures.in/assets/img/headset.png" alt="Image" style="height: 40px; margin-left: 150px;">
        <h3 style="text-align: center;">How can we help you?</h3>
    </div>
    <div class="card-container">
        <div class="card">
            <div class="img">
                <img src="https://apk.sportsfigures.in/assets/img/con.png" alt="Comment Icon" style="height: 35px; border-radius: 20px;">
            </div>
            <h3 style="margin-top: -45px; margin-left: 63px;">Chat On</h3>
            <a href="https://call.whatsapp.com/video/aqIpmoRgDOxrPk4U7jGJZA" target="_blank" style=" margin-left: 63px;">8181818864</a>
        </div>
        <div class="card">
            <div class="img">
                <img src="https://apk.sportsfigures.in/assets/img/email.png" alt="Comment Icon" style="height: 35px; border-radius: 20px;">
            </div>
            <h3 style="margin-top: -45px; margin-left: 63px;">Send us an E-mail</h3>
            <p><a href="mailto:kalyanofficialsatta@gmail.com" style=" margin-left: 63px;">kalyanofficialsatta@gmail.com</a></p>
        </div>
        <div class="card">
            <div class="img">
                <img src="https://apk.sportsfigures.in/assets/img/con.png" alt="Comment Icon" style="height: 35px; border-radius: 20px;">
            </div>
            <h3 style="margin-top: -45px; margin-left: 63px;">Call Us</h3>
            <a href="tel:8181818864" style=" margin-left: 63px;">8181818864</a>
        </div>
       <div class="card">
            <div class="img">
                <img src="./assets/img/linkedin.png" alt="Comment Icon" style="height: 35px; border-radius: 20px;">
            </div>
            <h3 style="margin-top: -45px; margin-left: 63px;">Chat Us</h3>
            <p><a href="https://www.linkedin.com/in/anjalichaudhry8690/" style=" margin-left: 63px;">https://www.linkedin.com/</a></p>
        </div>
    </div>
</div>
<?php include 'comman/contact_footer.php';
?>
<?php include 'comman/win_header.php'; ?>

<div class="abc">
    <span class="back-icon" onclick="goBack()">&#8592;</span>
    <h2>Bid History</h2>
</div>

<div class="container">
    <div class="card-container">
        <form method="post">
            <div class="card">
                <h3>Start Date</h3>
                <input type="date" name="startDate" id="startDate">
            </div>
            <div class="card">
                <h3>End Date</h3>
                <input type="date" name="endDate" id="endDate">
            </div>

            <div class="form-group">
                <button type="submit" name="submitForm">SUBMIT</button>
            </div>

            <div class="result">
                <?php
                function fetchBidHistory($startDate, $endDate, $uniqueToken)
                {
                    $apiUrl = 'https://disawar.techwarezen.shop/admin/api-bid-history-data';

                    $uniqueToken = isset($_COOKIE['localDataStore']) ? $_COOKIE['localDataStore'] : '';
                    $requestData = [
                        "env_type" => "Prod",
                        "app_key" => "HbegvJLeKwSFyApopniGHHBTZPocyH",
                        "unique_token" => $uniqueToken,
                        "bid_from" => $startDate,
                        "bid_to" => $endDate,
                    ];

                    $requestJson = json_encode($requestData);

                    $ch = curl_init($apiUrl);
                    curl_setopt_array($ch, [
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_POST => true,
                        CURLOPT_POSTFIELDS => $requestJson,
                        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
                    ]);

                    $response = curl_exec($ch);

                    if ($response === false) {
                        return 'Error: Unable to fetch data from the API. cURL error: ' . curl_error($ch);
                    }

                    curl_close($ch);

                    return json_decode($response, true);
                }

                $errorMessage = '';

                if (isset($_POST['submitForm'])) {
                    $startDate = $_POST['startDate'];
                    $endDate = $_POST['endDate'];

                    if (!empty($startDate) && !empty($endDate)) {
                        // Proceed to fetch and display bid history
                        $uniqueToken = isset($_COOKIE['localDataStore']) ? $_COOKIE['localDataStore'] : ''; 
                        $data = fetchBidHistory($startDate, $endDate, $uniqueToken);

                        if (is_string($data)) {
                            $errorMessage = $data;
                        } else {
                            if (isset($data['status']) && $data['status']) {
                                if (isset($data['bid_data'])) {
                                    echo '<ul>';
                                    foreach ($data['bid_data'] as $bid) {
                                        echo '<div class="card-formate">';
                                        echo '<p>Game Name: ' . $bid['game_name'] . '</p>';
                                        echo '<p>Pana: ' . $bid['pana'] . '</p>';
                                        echo '<p>Session: ' . $bid['session'] . '</p>';
                                        echo '<p>Closed Digits: ' . $bid['closedigits'] . '</p>';
                                        echo '<p>Points: ' . $bid['points'] . '</p>';
                                        echo '<p>Bid Date: ' . $bid['bid_date'] . '</p>';
                                        echo '</div>';
                                    }

                                    echo '</ul>';
                                } else {
                                    $errorMessage = 'Error: bid_data key is missing in the API response.';
                                }
                            } else {
                                $errorMessage = $data['msg'];
                            }
                        }
                    } else {
                        $errorMessage = 'Error: Please select both start and end dates.';
                    }
                }

                if (!empty($errorMessage)) {
                    echo '<p style="margin-top: -285px; margin-left: 57px;">' . $errorMessage . '</p>';
                }
                ?>
            </div>
        </form>
    </div>
</div>

<?php include 'comman/contact_footer.php'; ?>
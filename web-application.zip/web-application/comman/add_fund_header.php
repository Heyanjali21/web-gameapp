<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Fund</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-qh8Xz5g+5+pru3AKbBxyTsvYZJTRs/46g2hghT8cF4vj84Qw4rcq5egxxjczD2hpjli4ItRVr7YqNJo6ikfCA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        .container {
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border-radius: 0px;
            margin: auto;
            max-width: 400px;
            position: relative;
            height: 100vh;
        }

        .card-container {
            margin-top: 20px;
            display: flex;
            flex-direction: column;
        }

        .card {
            background-color: rgb(255, 255, 255);
            box-shadow: 0px 20px 40px rgba(0, 0, 0, 0.1);
            border-radius: 20px;
            margin-bottom: 10px;
            height: 80px;
            width: 100%;
            font-size: 15px;
        }

        .button-container {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
           
        }

        button {
            padding: 5px 20px;
            background-color: #702424;
            border-radius: 10px;
            margin-bottom: 22px;
           
        }

        .logo {
            max-width: 100%;
            height: auto;
            margin-bottom: 20px;
            position: absolute;
            margin-top: -167px;
        }

        .abc {
            background-color: #702424;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: auto;
            max-width: 400px;
        }

        .abc {
            display: flex;
            align-items: center;
        }

        .back-icon {
            margin-right: 20px;
            cursor: pointer;
        }


        .btn {
            border-radius: 20px;
            width: 100%;
            height: 50px;
            background-color: #702424;
            color: #fff;
            margin-top: 20px;
        }

        .card-conn {
            display: flex;
            flex-direction: column;
        }

        .c {
            background-color: rgb(96, 27, 27);
            border-radius: 70px;
            margin-bottom: 10px;
            height: 60px;
            width: 30%;
        }

        input {
            padding: 10px;
            width: calc(100% - 30px);
            box-sizing: border-box;
            margin-bottom: 40px;
            border-radius: 10px;
            background: beige;
            margin-top: 10px;

        }
        
    </style>
</head>

<body>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Fund</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
        integrity="sha512-qh8Xz5g+5+pru3AKbBxyTsvYZJTRs/46g2hghT8cF4vj84Qw4rcq5egxxjczD2hpjli4ItRVr7YqNJo6ikfCA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            margin: 0;
            padding: 0 20px;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin-top: 40px;
            
        }

        .container {
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border-radius: 0px;
            margin: auto;
            max-width: 400px;
            position: relative;
            border: 2px solid brown;
        }

        .input-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: 30px;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            background-color: white;
            border: 2px solid brown;
            border-radius: 10px;
        }

        .button-container {
            display: flex;
            justify-content: space-between;
        }

        button {
            width: 48%;
            padding: 10px;
            cursor: pointer;
            border-radius: 20px;
            background-color: brown;
            color: white;
            border: 2px solid rgb(65, 65, 14);
        }

        .card {
            background-color: blanchedalmond;
            height: 50px;
            border-radius: 10px;
            width: 98%;
            text-align: center;
        }
    </style>
</head>

<body>
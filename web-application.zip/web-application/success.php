<?php
include 'comman/succsess_header.php';

// Check if the transaction ID is present in the URL
if(isset($_GET['razorpay_payment_id'])){
    $transactionId = $_GET['razorpay_payment_id'];
    $dateTime = date("Y-m-d H:i:s"); // Get the current date and time
    // Display success message along with the transaction ID, date, and time
    echo '<div class="abc">';
    echo '    <span class="back-icon" onclick="goBack()">&#8592;</span>';
    echo '    <h2>Transaction Success</h2>';
    echo '</div>';
    echo '<div class="container">';
    echo '    <div class="header">';
    echo '        <p>Transaction ID: ' . $transactionId . '</p>';
    echo '        <p>Date and Time: ' . $dateTime . '</p>';
    echo '    </div>';
    echo '    <div class="card-container">';
    echo '        <!-- Your success content goes here -->';
    echo '    </div>';
    echo '</div>';
} else {
    // Redirect to an error page or handle the case where the transaction ID is not present
    header('Location: error_page.php');
    exit();
}

include 'comman/contact_footer.php';
?>

<?php
session_start();

$mobile = $_POST['mobile'];
$password = $_POST['password'];

$envType = 'Prod';
$appKey = 'HbegvJLeKwSFyApopniGHHBTZPocyH';
$uniqueToken = '4AR6tSuQEquKeUL7Uwh1ZnkaJz0vrK';

$data = [
    'mobile' => $mobile,
    'password' => $password,
    'device_id' => "",
    'env_type' => $envType,
    'app_key' => $appKey,
    'unique_token' => $uniqueToken,
];

$jsonData = json_encode($data);

$apiUrl = 'https://disawar.techwarezen.shop/admin/api-user-login';

$ch = curl_init($apiUrl);

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Content-Length: ' . strlen($jsonData),
]);

$response = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Curl error: ' . curl_error($ch);
    exit();
}

curl_close($ch);

$responseArray = json_decode($response, true);

if (isset($responseArray['status']) && $responseArray['status'] == 'true') {
    $uniqueToken = $responseArray["unique_token"];
    $_SESSION['unique_token'] = $uniqueToken;
    $_SESSION['user_logged_in'] = true;
  
     $st = setcookie('localDataStore', $uniqueToken, time() + 36000, '/', '', true, true);
     $uniqueToken = $_COOKIE['localDataStore'];
    // echo $uniqueToken;

    
    if (isset($_COOKIE['localDataStore'])) {
      header("Location: home.php");
    exit();  
    }

   

} else {
    header("Location: login_Page.php");
    exit();    
}
?>

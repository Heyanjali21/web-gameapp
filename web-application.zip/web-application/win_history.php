<?php include 'comman/win_header.php';
?>
<div class="abc">
    <span class="back-icon" onclick="goBack()">&#8592;</span>
    <h2>Win History</h2>
</div>
<div class="container">
    <div class="card-container">
        <div class="card">
            <h3>Start Date</h3>
            <input type="date" id="startDate">
        </div>
        <div class="card">
            <h3>End Date</h3>
            <input type="date" id="endDate">
        </div>
    </div>
    <div class="form-group">
        <button type="submit">SUBMIT</button>
    </div>
</div>

<?php include 'comman/contact_footer.php';
?>
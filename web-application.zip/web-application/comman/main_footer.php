<!-- for redirect the game page with game id -->
<script>
    function redirectToPage(msg, game_id, game_name) {
        console.log('Message:', msg);

        if (msg && game_id) {
            if (msg.toLowerCase() === 'market running') {
                console.log('Redirecting to game.php with Game ID:', game_id, 'and Game Name:', game_name);
                
                // Store both game ID and game name in cookies
                document.cookie = 'game_id=' + game_id;
                document.cookie = 'game_name=' + encodeURIComponent(game_name);

                window.location.href = 'game.php?game_id=' + game_id + '&game_name=' + encodeURIComponent(game_name);
            } else {
                console.log('Message does not require redirection.');
            }
        } else {
            console.log('Message or Game ID not available.');
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        var videoLinks = document.querySelectorAll('.video-link');

        videoLinks.forEach(function(link) {
            link.addEventListener('click', function() {
                var msg = this.getAttribute('data-msg');
                var game_id = this.getAttribute('data-game-id');
                var game_name = this.getAttribute('data-game-name');

                // Store the game ID and game name in cookies
                document.cookie = 'game_id=' + game_id;
                document.cookie = 'game_name=' + encodeURIComponent(game_name);

                redirectToPage(msg, game_id, game_name);
            });
        });
    });
</script>


<!-- for menu -->

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const menuIcon = document.getElementById("menu-icon");
        const mainMenu = document.getElementById("main-menu");

        menuIcon.addEventListener("click", function() {
            mainMenu.style.display = mainMenu.style.display === "none" ? "flex" : "none";
        });

        window.addEventListener("resize", function() {
            if (window.innerWidth > 768) {
                mainMenu.style.display = "none";
            }
        });
    });
</script>
<script>
    var shareIcon = document.getElementById("share-icon");
    shareIcon.addEventListener("click", function() {
        var shareUrl = "main.html";
        var shareText = "Check out this cool app on Satta!";
        var whatsappLink = "whatsapp://send?text=" + encodeURIComponent(shareText + " " + shareUrl);
        var instagramLink = "https://www.instagram.com/share?url=" + encodeURIComponent(shareUrl);
        var facebookLink = "https://www.facebook.com/sharer/sharer.php?u=" + encodeURIComponent(shareUrl);
        var linkedinLink = "https://www.linkedin.com/shareArticle?url=" + encodeURIComponent(shareUrl);
        var telegramLink = "https://t.me/share/url?url=" + encodeURIComponent(shareUrl) + "&text=" + encodeURIComponent(shareText);
        window.open(whatsappLink);
        window.open(instagramLink);
        window.open(facebookLink);
        window.open(linkedinLink);
        window.open(telegramLink);
    });
</script>

<script>
    function openContactPage() {
        window.location.href = 'contact_page.php';
    }

    function play() {
        window.location.href = 'how_play.php';
    }
</script>
<script>
    function openNav() {
        document.getElementById("mySidepanel").style.width = "250px";
    }

    function closeNav() {
        document.getElementById("mySidepanel").style.width = "0";
    }
</script>
<script>
    function goBackk() {
        window.location.href = 'main.html';
    }
</script>

<!-- for buuton -->
<script>
    document.getElementById("bellButton").addEventListener("click", function() {
        window.location.href = "bell.html";
    });
</script>


<!-- for logout -->

<script>
    function openModal() {
        $("#myModal").show();
    }

    $("#confirmYes").on("click", function() {
        localStorage.clear();
        window.location.href = "login_Page.php";
    });

    $("#confirmNo").on("click", function() {
        $("#myModal").hide();
    });
</script>


<script>
    $(document).ready(function() {
        $("#loginForm").submit(function(e) {
            e.preventDefault();

            var formData = $(this).serialize();

            $.ajax({
                type: "POST",
                url: "game_api.php",
                data: formData,
                success: function(response) {
                    $("#message").html(response);
                    if (response.indexOf('Login successful') !== -1) {

                        console.log(response);


                    }
                }
            });
        });
    });
</script>


</body>

</html>
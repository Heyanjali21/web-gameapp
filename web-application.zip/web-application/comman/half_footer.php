<script>
        function goBack() {
            window.location.href = 'game.php';
        }
    </script>
    <script>
        $(document).ready(function() {
            $("#profileForm").submit(function(e) {
                e.preventDefault();

                var formData = $(this).serialize();

                $.ajax({
                    type: "POST",
                    url: "walletapi.php",
                    data: formData,
                    success: function(response) {
                        $("#message").html(response);
                    }
                });
            });
        });
    </script>

<script>
        function displayFormData() {
            const status = document.querySelector('input[name="status"]:checked');
            const amount = document.getElementById('amount').value;
            const points = document.getElementById('number').value;

            // Create a new row in the table
            const table = document.getElementById("dataTable");
            const row = table.insertRow(1); // Insert at the second row (index 1)
            const cell1 = row.insertCell(0);
            const cell2 = row.insertCell(1);
            const cell3 = row.insertCell(2);

            // Populate the cells with the entered data
            cell1.innerHTML = status ? status.value : "Not selected";
            cell2.innerHTML = amount;
            cell3.innerHTML = points;

            // Show the table
            table.style.display = "table";
            document.getElementById("showDataBtn").style.display = "block";
        }


        function validateAndSubmitForm() {
            const enteredValue = document.getElementById("amount").value;

            if (/^\d{3}$/.test(enteredValue) && isDigitAllowed(enteredValue)) {
                document.getElementById("amountError").textContent = "";
                displayFormData();
            } else {
                document.getElementById("amountError").textContent = "Not a valid digit. Please enter a valid three-digit number from the allowed set.";
            }
        }

        function isDigitAllowed(digit) {
            const allowedDigits = {
                "1": [100, 110, 112, 113, 114, 115, 116, 117, 118,
                 119, 122, 133, 144, 155, 166, 177, 188, 199],
                "2": [200, 220, 223, 224, 225, 226, 227, 228, 229, 233, 244, 255, 266, 277, 288, 299],
                "3": [300, 330, 334, 335, 336, 337, 338, 339, 344, 355, 366, 377, 388, 399],
                "4": [400, 440, 445, 446, 447, 448, 449, 455, 466, 477, 488, 499],
                "5": [500, 550, 556, 557, 558, 559, 566, 577, 588, 599],
                "6": [600, 660, 667, 668, 669, 677, 688, 699],
                "7": [700, 770, 778, 779, 788, 799],
                "8": [800, 880, 889, 899],
            };

            const firstDigit = digit.charAt(0);
            const numericValue = parseInt(digit);

            return allowedDigits[firstDigit] && allowedDigits[firstDigit].includes(numericValue);
        }
    </script>


  <!--for suggestion digit-->

<script>
    function suggestDigits(value) {
        document.getElementById("suggestions").innerHTML = "";
        const allowedDigits = {
             "1": [100, 110, 112, 113, 114, 115, 116, 117, 118,
                 119, 122, 133, 144, 155, 166, 177, 188, 199],
                "2": [200, 220, 223, 224, 225, 226, 227, 228, 229, 233, 244, 255, 266, 277, 288, 299],
                "3": [300, 330, 334, 335, 336, 337, 338, 339, 344, 355, 366, 377, 388, 399],
                "4": [400, 440, 445, 446, 447, 448, 449, 455, 466, 477, 488, 499],
                "5": [500, 550, 556, 557, 558, 559, 566, 577, 588, 599],
                "6": [600, 660, 667, 668, 669, 677, 688, 699],
                "7": [700, 770, 778, 779, 788, 799],
                "8": [800, 880, 889, 899],
            };


        // Check if the entered value is a valid single digit (1 to 9)
        if (value.length === 1 && Object.keys(allowedDigits).includes(value)) {
            let suggestionsList = allowedDigits[value];

            if (suggestionsList) {
                suggestionsList.forEach(suggestion => {
                    let suggestionElement = document.createElement("div");
                    suggestionElement.classList.add("suggestion");
                    suggestionElement.textContent = suggestion;
                    suggestionElement.addEventListener("click", function () {
                        document.getElementById("amount").value = suggestion;
                        document.getElementById("suggestions").innerHTML = "";
                    });

                    document.getElementById("suggestions").appendChild(suggestionElement);
                });
            }
        } 
    }
</script>

<script>
    function handleOption(option) {
        const labelForAmount = document.getElementById("labelForAmount");
        const amountInput = document.getElementById("amount");

        if (option === 'open') {
            labelForAmount.textContent = 'Open Digit';
        } else if (option === 'close') {
            labelForAmount.textContent = 'Close Digit';
        }
    }
</script>

<!-- for disallow 0 or negative number -->

<script>
    document.getElementById("number").addEventListener("input", function () {
        let inputValue = parseInt(this.value);

        if (isNaN(inputValue) || inputValue < 10) {
            document.getElementById("error-message").textContent = "Please enter a number greater than or equal to 10.";
            this.setCustomValidity("Please enter a number greater than or equal to 10.");
        } else {
            document.getElementById("error-message").textContent = "";
            this.setCustomValidity("");
        }
    });
</script>

<!--for retching the data from table-->
<script>
    function submitForm() {
        var closeDigit = document.getElementById('totalBids') ? document.getElementById('totalBids').textContent : '';
        var points = calculateTotalPoints(); 
        var gameType = document.getElementById('gameType') ? document.getElementById('gameType').textContent : '';
        window.location.href = 'show_result.php?closeDigit=' + closeDigit + '&points=' + points + '&status=' + gameType;
    }

    function calculateTotalPoints() {
        var sumTotalPoints = 0;

        var dataTable = document.getElementById('dataTable');
        if (dataTable) {
            var rows = dataTable.getElementsByTagName('tr');

            for (var i = 1; i < rows.length; i++) {
                var cells = rows[i].getElementsByTagName('td');
                var points = parseInt(cells[2].innerHTML);

                if (!isNaN(points)) {
                    sumTotalPoints += points;
                }
            }
        }

        return sumTotalPoints;
    }
</script>


</body>
</html>
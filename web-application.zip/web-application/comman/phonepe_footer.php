<script>
    function submitForm() {
        var phoneNumber = document.getElementById("number").value;
        window.location.href = "get_payment.php?phone=" + phoneNumber;
    }

    function moveLeft() {
        // Your moveLeft function implementation here
    }
</script>
</body>

</html>
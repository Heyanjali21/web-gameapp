<?php
$envType = 'Prod';
$appKey = 'HbegvJLeKwSFyApopniGHHBTZPocyH';
$uniqueToken = '4AR6tSuQEquKeUL7Uwh1ZnkaJz0vrK';

$jsonData = json_encode($data);

$apiUrl = 'https://disawar.techwarezen.shop/admin/api-check-game-status';
$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Content-Length: ' . strlen($jsonData),
]);
$response = curl_exec($ch);

if (curl_errno($ch)) {
    echo 'Curl error: ' . curl_error($ch);
}
curl_close($ch);
// $responseArray = json_decode($response, true);
// // Check if the 'unique_token' key exists in the response

echo $response;
?>

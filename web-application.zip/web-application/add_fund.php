<?php include 'comman/add_fund_header.php';
?>
<div class="abc">
    <span class="back-icon" onclick="goBack()">&#8592;</span>
    <h2>Add Fund</h2>
</div>

<!-- for virtical card -->
<div class="container">
    <div class="card-conn">
        <div class="c" style="text-align: center" ;>
            <h3 style="color: #fff;">History</h3>
        </div>
    </div>
    <?php
$apiKey = "rzp_test_YF9ifmcG2fAEHV";
$amount = isset($_POST['amount']) ? max(0, (int)$_POST['amount']) : 100;
?>
<form id="payment-form" action="handle_payment.php" method="POST">
    <div class="amount">
        <label for="amount">Enter Amount</label><br>
        <input type="number" id="amount" name="amount" placeholder="Enter Amount" required min="0" oninput="updateAmount()">
    </div>
    <div class="button-container">
        <button type="button" onclick="redirectToPhonePe()" style="color: white;">PhonePe</button>
        <button type="button" onclick="redirectToGooglePay()" style="color: white;">GooglePay</button>
        <button type="button" onclick="redirectToOther()" style="color: white;">Other</button>
    </div>

    <script src="https://checkout.razorpay.com/v1/checkout.js"
    data-key="<?php echo $apiKey; ?>"
    data-amount="<?php echo $amount * 100; ?>"
    data-currency="INR"
    data-id="<?php echo 'OID' . rand(1, 100) . 'END'; ?>"
    data-buttontext="Pay with Razorpay"
    data-name="Techwarazen"
    data-description="Development Services"
    data-image="https://example.com/your_logo.jpg"
    data-theme.color="#F37254"></script>
</form>



    <!-- for button -->
    <!-- <input type="submit" value="Pay Nowiiiii" class="btn"> -->
    <!-- <button >PROCEED</button> -->




    <div class="card-container">
        <div class="card">
            <h3 style=" margin-left: 20px">Type amount in a box</h3>
        </div>
    </div>

    <div class="card-conn">
        <div class="card">
            <h3 style=" margin-left: 20px">Amount should 500 minimum</h3>
        </div>
    </div>

    <div class="card-conn">
        <div class="card">
            <h3 style=" margin-left: 20px">Press icon by which payment mode you add money</h3>
        </div>
    </div>

    <div class="card-conn">
        <div class="card">
            <h3 style=" margin-left: 20px">Then it will automatically take you to the payment application</h3>
        </div>
    </div>

    <div class="card-conn">
        <div class="card">
            <h3 style=" margin-left: 20px">As you finish your transaction then point will automatically update</h3>
        </div>
    </div>

    <div class="card-conn">
        <div class="card">
            <h3 style=" margin-left: 20px">If you found any problem please send me your problem screenshot on my whatsapp</h3>
        </div>
    </div>

    <div class="card-conn">
        <div class="card">
            <h3 style=" margin-left: 20px">We solve your problem in a minit</h3>
        </div>
    </div>
</div>
<?php include 'comman/fund_footer.php';
?>

<?php include 'comman/contact_header.php';
?>
<div class="abc">
    <span class="back-icon" onclick="goBack()">&#8592;</span>
    <h2>Contact Us</h2>
</div>
<div class="container">
    <div>
    <img src="https://disawar.techwarezen.shop/web-app/assets/img/headset.png" alt="Image" style="height: 40px; margin-left: 150px;">
        <h3 style="text-align: center;">How can we help you?</h3>
    </div>
    <div class="card-container">
        <div class="card">
            <h3 style="margin-top: -10px;">Chat On</h3>
            <a href="https://call.whatsapp.com/video/aqIpmoRgDOxrPk4U7jGJZA" target="_blank">8181818864</a>
        </div>
        <div class="card">
            <h3 style="margin-top: -10px;">Send us an E-mail</h3>
            <p><a href="mailto:kalyanofficialsatta@gmail.com">kalyanofficialsatta@gmail.com</a></p>
        </div>
        <div class="card">
            <h3 style="margin-top: -10px;">Call Us</h3>
            <a href="tel:8181818864">8181818864</a>
        </div>
        <div class="card">
            <h3 style="margin-top: -10px;">Chat Us</h3>
            <p>..........</p>
        </div>
    </div>
</div>
<?php include 'comman/contact_footer.php';
?>

<?php include 'comman/change_header.php';
?>
<div class="abc">
        <span class="back-icon" onclick="goBack()">&#8592;</span>
        <h2>Change Password</h2>
    </div>
    <div class="container">
        <form id="changePasswordForm"  id="myForm" onsubmit="event.preventDefault(); submitForm();" method="POST">
            <div class="form-group">
                <label for="oldPassword">Enter Old Password</label>
                <input type="password" id="oldPassword" name="old_pass" placeholder="At least 6 characters" required>
                <i class="fas fa-eye eye-icon" onclick="togglePasswordVisibility('oldPassword')"></i>
            </div>
            <div class="form-group">
                <label for="newPassword">Enter New Password</label>
                <input type="password" id="newPassword" name="new_pass" placeholder="At least 6 characters" required>
                <i class="fas fa-eye eye-icon" onclick="togglePasswordVisibility('newPassword')"></i>
            </div>
            <div class="form-group">
                <label for="confirmPassword">Enter Confirm Password</label>
                <input type="password" id="confirmPassword" name="confirmPassword" placeholder="At least 6 characters" required>
                <i class="fas fa-eye eye-icon" onclick="togglePasswordVisibility('confirmPassword')"></i>
            </div>
            <!--<button type="button" onclick="changePassword()">CHANGE</button>-->
             <button type="submit" class="button">CHANGE</button>

            <div class="api" style=" margin-top: 20px; ">
                <div id="apiResponseContainer"></div>
            </div>
        </form>
        <div id="message"></div>
    </div>
    <?php include 'comman/password_footer.php';
?>
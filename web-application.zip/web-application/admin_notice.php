
<?php include 'comman/notic_header.php';
?>
<div class="abc">
    <span class="back-icon" onclick="goBack()">&#8592;</span>
    <h2>Admin Notice</h2>
</div>
<div class="container">
    <div class="card-container">
        <div class="card">
            <h3>WELCOME TO KALYAN GROUP OFFICIAL</h3>
        </div>
    </div>
</div>

<?php include 'comman/contact_footer.php';
?>
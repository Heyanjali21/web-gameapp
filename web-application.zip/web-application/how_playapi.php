<?php
        $apiUrl = 'https://disawar.techwarezen.shop/admin/api-how-to-play';
        $selectedDate = "";
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        }
        $tokenData = array(
            "env_type" => "Prod",
            "app_key" => "HbegvJLeKwSFyApopniGHHBTZPocyH",
            "unique_token" => "4AR6tSuQEquKeUL7Uwh1ZnkaJz0vrK"
        );


        $tokenJson = json_encode($tokenData);

        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $tokenJson);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

        $response = curl_exec($ch);

        if ($response === false) {
            echo '<tr><td colspan="4">Error: Unable to fetch data from the API. cURL error: ' . curl_error($ch) . '</td></tr>';
        } else {
            $data = json_decode($response, true);

            if ($data === null || !isset($data['result'])) {
                echo '<tr><td colspan="4">Error: Failed to parse JSON data or missing "result" data.</td></tr>';
            } else {
                $resultData = $data['result'];

                // Pagination logic
                $perPage = 10;
                $totalResults = count($resultData);
                $currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;

                // Calculate total pages
                $totalPages = ceil($totalResults / $perPage);

                // Validate current page
                if ($currentPage < 1) {
                    $currentPage = 1;
                } elseif ($currentPage > $totalPages) {
                    $currentPage = $totalPages;
                }

                // Iterate over the data and display cards
                foreach ($resultData as $row) {
        ?>
                    <div class="card">
                        <h5 class="card-title name-ico"><?php echo $row['game_name']; ?></h5>
                        <p class="card-text" style="color: red;"><?php echo $row['msg']; ?></p>
                        <p class="card-text center-text" style="color: green;">Open Bids:
                        <p style="color: green;" class="time"><?php echo $row['open_time']; ?></p>
                        </p>
                        <p class="card-text center-textt" style="color: red;">Close Bids:
                        <p style="color: red;" class="time"><?php echo $row['close_time']; ?></p>
                        </p>
                        <!-- Add a link around the video icon with data-msg attribute -->
                        <a href="javascript:void(0);" class="video-link" data-msg="<?php echo strtolower($row['msg']); ?>">
                        <img src="http://localhost/application/assets/img/video.png" alt="Video Icon" class="video-icon">
                        </a>
                        <img src="http://localhost/application/assets/img/alram.png" alt="Video Icon" class="video-ii">
                    </div>
        <?php
                }
            }
        }

        curl_close($ch);
        ?>
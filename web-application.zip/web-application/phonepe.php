<?php include 'comman/phonepe_header.php';
?>

<div class="container">
    <div class="card">
       <img src="https://disawar.techwarezen.shop/web-app/assets/img/phonepe.png" style="height: 30px; margin-top: 10px; margin-left: -113px; border-radius: 20px;">
        <h3 style="margin-top: -28px;">PhonePe</h3>
    </div>
    <div class="input-container">
        <form action="get_payment.php" method="POST">
            <label for="number" style="margin-left: 2%;">Add PhonePe Number</label>
            <input type="number" placeholder="Enter number" id="number">
    </div>
    <div class="button-container">
        <button onclick="moveLeft()">CANCEL</button>
        <button onclick="moveRight()">SUBMIT</button>
    </div>
    </form>
</div>


<?php include 'comman/phonepe_footer.php';
?>
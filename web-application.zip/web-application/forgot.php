<?php
    $mobile = $_POST["mobile"];
  
    $envType = 'Prod';
    $appKey = 'HbegvJLeKwSFyApopniGHHBTZPocyH';
   


    $uniqueToken =  isset($_COOKIE['localDataStore']) ? $_COOKIE['localDataStore'] : '';
    
  
    $data = [
        'mobile' => $mobile,
        'env_type' => $envType,
        'app_key' => $appKey,
        'unique_token' => $uniqueToken,
    
     
    ];

    $jsonData = json_encode($data);
    
    $apiUrl = 'https://disawar.techwarezen.shop/admin/api-forget-check-mobile';
 
    $ch = curl_init($apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Content-Length: ' . strlen($jsonData),
    ]);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        echo 'Curl error: ' . curl_error($ch);
    }
    
    // Close cURL session
    curl_close($ch);
    
    // Display the API response
    echo $response;
    ?>
    
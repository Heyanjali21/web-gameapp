<?php include 'comman/result_header.php'; ?>

<div class="abc">
    <span class="back-icon" onclick="goBack()">&#8592;</span>
    <h2>Single Digit</h2>
</div>
<form class="myForm">
<div class="container">
    <p style="margin-bottom: -5px;">Once you placed a bid, it will not be canceled in any situation.</p>
    <div class="cardd" style="background-color: rgb(250, 99, 17);">
        <p style="margin-top: -4px;">Single Digit</p>
    </div>

    <p style="margin-bottom: -5px;">Total Bids</p>
    <div class="cardd" id="totalBids"><?php echo isset($_GET['closeDigit']) ? $_GET['closeDigit'] : ''; ?></div>

    <p style="margin-bottom: -5px;">Total Points</p>
    <div class="cardd" id="totalPoints"><?php echo isset($_GET['points']) ? $_GET['points'] : ''; ?></div>

    <p style="margin-bottom: -5px;">Game Type</p>
    <div class="cardd" id="gameType"><?php echo isset($_GET['status']) ? $_GET['status'] : ''; ?></div>


    <div class="button-container">
        <button onclick="goLeft()">CANCEL</button>
        <button type="button" class="button" onclick="submitForm()">SUBMIT</button>


        <div class="api" style="margin-top: 20px;">
            <div id="apiResponseContainer"></div>
        </div>
    </div>
</div>
</form>
<script>
   function submitForm() {
    var formElement = document.getElementById('myForm');

    if (formElement) {
        var xhr = new XMLHttpRequest();
        var formData = new FormData(formElement);

        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4) {
                if (xhr.status == 200) {
                    // Parse the JSON response
                    var jsonResponse = JSON.parse(xhr.responseText);

                    // Display only the "msg" property
                    document.getElementById("apiResponseContainer").innerHTML = jsonResponse.msg;
                } else {
                    // Display an error message
                    document.getElementById("apiResponseContainer").innerHTML = "Error: " + xhr.status;
                }
            }
        };

        xhr.open("POST", "process_form.php", true);
        xhr.send(formData);
    } else {
        console.error('Error: Form element not found.');
    }
}


</script>

<?php include 'comman/game_page_footer.php'; ?>
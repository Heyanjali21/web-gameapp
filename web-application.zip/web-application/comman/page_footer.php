<script>
        function goBack() {
            window.location.href = 'main.php';
        }
    </script>
    <script>
        $(document).ready(function() {
            $("#profileForm").submit(function(e) {
                e.preventDefault();

                var formData = $(this).serialize();

                $.ajax({
                    type: "POST",
                    url: "walletapi.php",
                    data: formData,
                    success: function(response) {
                        $("#message").html(response);
                    }
                });
            });
        });
    </script>


    <script>
    document.getElementById('openButton').addEventListener('click', function() {
        document.getElementById('labelForAmount').innerText = 'Open Digit';
    });

    document.getElementById('closeButton').addEventListener('click', function() {
        document.getElementById('labelForAmount').innerText = 'Close Digit';
    });
</script>
<script>
    // JavaScript for slider functionality (you may need to customize this based on your requirements)
    let currentIndex = 0;
    const slider = document.querySelector('.slider');

    function showSlide(index) {
        const translateValue = -index * 100 + '%';
        slider.style.transform = 'translateX(' + translateValue + ')';
    }

    function nextSlide() {
        currentIndex = (currentIndex + 1) % <?php echo count($data['sliderdata']); ?>;
        showSlide(currentIndex);
    }

    function prevSlide() {
        currentIndex = (currentIndex - 1 + <?php echo count($data['sliderdata']); ?>) % <?php echo count($data['sliderdata']); ?>;
        showSlide(currentIndex);
    }

    setInterval(nextSlide, 3000); // Auto slide every 3 seconds
</script>
</body>

</html>
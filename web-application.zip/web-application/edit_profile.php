
<?php include 'comman/edit_header.php';
?>
<div class="abc">
        <span class="back-icon" onclick="goBack()">&#8592;</span>
        <h2>Edit Profile</h2>
    </div>
    <div class="container">
        <form  id="profileForm" id="myForm" onsubmit="event.preventDefault(); submitForm();" method="POST">
            <div>
                <img src="https://disawar.techwarezen.shop/web-app/assets/img/profile.jpeg" alt="Image" style="height: 90px; margin-left: 120px; border-radius: 50px;">
            </div>
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" id="name" name="name" placeholder="Enter your name" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" placeholder="Enter your email" required>
            </div>
            <button type="submit" class="button">SAVE CHANGE</button>

            <div class="api" style=" margin-top: 20px; ">
                <div id="apiResponseContainer"></div>
            </div>
        </form>
        <div id="message"></div>
    </div>
    <?php include 'comman/profile_footer.php';
?>
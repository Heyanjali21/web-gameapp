<script>
    function goBack() {
        window.location.href = 'profile_page.php';
    }
</script>
<script>
    $(document).ready(function() {
        $("#signupform").submit(function(e) {
            e.preventDefault();

            var formData = $(this).serialize();

            $.ajax({
                type: "POST",
                url: "changepassapi.php",
                data: formData,
                success: function(response) {
                    $("#message").html(response);
                    if (response.indexOf('register successful') !== -1) {
                        window.location.href = "profile.html";
                    }
                }
            });
        });
    });
</script>


<script>
    function togglePasswordVisibility(inputId) {
        var inputElement = document.getElementById(inputId);
        var eyeIcon = document.querySelector(`#${inputId} + .eye-icon`);

        if (inputElement.type === "password") {
            inputElement.type = "text";
            eyeIcon.classList.remove("fa-eye");
            eyeIcon.classList.add("fa-eye-slash");
        } else {
            inputElement.type = "password";
            eyeIcon.classList.remove("fa-eye-slash");
            eyeIcon.classList.add("fa-eye");
        }
    }

    function changePassword() {
        document.getElementById("changePasswordForm").submit();
    }
</script>


</body>

</html>
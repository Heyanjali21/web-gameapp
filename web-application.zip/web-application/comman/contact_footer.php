<script>
        function goBack() {
            window.location.href = 'home.php'; 
        }
    </script>

<script>
    function openNav() {
        document.getElementById("mySidepanel").style.width = "250px";
    }

    function closeNav() {
        document.getElementById("mySidepanel").style.width = "0";
    }
</script>
</body>

</html>

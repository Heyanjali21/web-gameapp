// Add a scroll event listener to your window
window.addEventListener('scroll', function () {
    // Get the navigation bar and profile container elements
    var nav = document.querySelector('nav');
    var profileContainer = document.querySelector('.profile-container');

    // Get the scroll position
    var scrollPosition = window.scrollY;

    // Add or remove the 'scroll' class based on the scroll position
    if (scrollPosition > 0) {
        nav.classList.add('scroll');
        profileContainer.style.top = nav.offsetHeight + 'px';
    } else {
        nav.classList.remove('scroll');
        profileContainer.style.top = 0;
    }
});

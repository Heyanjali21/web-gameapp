
<?php include 'comman/profile_header.php';
?>
<div class="abc">
        <span class="back-icon" onclick="goBack()">&#8592;</span>
        <h2>Profile</h2>
    </div>
    <div class="container">
        <div class="profile-container">
                <div>
                    <?php
                    $apiUrl = 'https://disawar.techwarezen.shop/admin/api-get-profile';

                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    }

                    $uniqueToken = isset($_COOKIE['localDataStore']) ? $_COOKIE['localDataStore'] : '';
                    $tokenData = array(
                        "env_type" => "Prod",
                        "app_key" => "HbegvJLeKwSFyApopniGHHBTZPocyH",
                        "unique_token" => $uniqueToken,
                    );

                    // echo $uniqueToken;
                    $tokenJson = json_encode($tokenData);

                    $ch = curl_init($apiUrl);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $tokenJson);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

                    $response = curl_exec($ch);

                    if ($response === false) {
                        echo '<tr><td colspan="4">Error: Unable to fetch data from the API. cURL error: ' . curl_error($ch) . '</td></tr>';
                    } else {
                        $data = json_decode($response, true);
                        if (isset($data['status']) && $data['status']) {
                            if (isset($data['profile'])) {
                                $resultData = $data['profile'][0];
                    ?>
                              <img src="https://disawar.techwarezen.shop/web-app/assets/img/profile.jpeg" alt="Profile Logo" class="profile-logo">
                                <div> <?php echo $resultData["mobile"]; ?>  </div>
                                <div> <?php echo $resultData["user_name"]; ?> </div>
                    <?php
                            } else {
                                echo '<tr><td colspan="4">Error: Profile key is missing in the API response.</td></tr>';
                            }
                        } else {
                            echo '<tr><td colspan="4">Error: ' . $data['msg'] . '</td></tr>';
                        }
                    }

                    curl_close($ch);
                    ?>
                </div>
        </div>
        <div class="header">
        </div>
        <div class="card-container">
            <div class="card" style="text-align: center; display: flex; align-items: center; justify-content: center;">
                <a href="edit_profile.php" style="color: rgb(255, 255, 255);" >EDIT PROFILE</a>
            </div>
            <div class="card" style="text-align: center; display: flex; align-items: center; justify-content: center;">
                <a href="change_password.php" style="color: rgb(255, 255, 255);" >CHANGE PASSWORD</a>
            </div>
            <div class="card" style="text-align: center; display: flex; align-items: center; justify-content: center;">
                <a href="contact_page.php" style="color: rgb(255, 255, 255);" >HELP & SUPPORT</a>
            </div>
            <div class="card" style="text-align: center; display: flex; align-items: center; justify-content: center;">
                <a href="#" id="logoutBtn" style="color: rgb(255, 255, 255);" >LOG OUT</a>
    
            </div>
        </div>
    </div>

    <?php include 'comman/contact_footer.php';
?>
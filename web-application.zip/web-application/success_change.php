<?php include 'comman/pana_header.php';
?>
<div class="abc">
    <span class="back-icon" onclick="goBack()">&#8592;</span>
    <h2>Successfully change</h2>
</div>
<?php
if (isset($_GET['success']) && $_GET['success'] == 1) {
    $successMessage = "Password successfully changed!";
} else {
    $successMessage = ""; 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password Page</title>
</head>
<body>

<div class="container">
    <?php echo $successMessage; ?>
</div>

<?php include 'comman/password_success_footer.php';
?>
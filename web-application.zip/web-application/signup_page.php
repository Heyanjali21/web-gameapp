
<?php include 'comman/auth_header.php';
?>
<div style="color: black;">
    <!--<div class="profile-container">-->
    <!--    <img src="https://disawar.techwarezen.shop/web-app/assets/img/logo.png" alt="Profile Logo" class="profile-logo">-->
    <!--</div>-->
    <div class="signup-container">
        <h2 style="color: white;">Sign Up</h2>
        <form id="signupform" class="signup-form" action="<?php echo 'signup.php'; ?>" method="POST">
            <div class="form-group">
                <label for="username" style="color: white;">Username:</label>
                <input type="text" id="name" name="name" required  style="color: white;">
            </div>
            <div class="form-group">
                <label for="mobile" style="color: white;">Phone Number:</label>
                 <input type="text" id="mobile" name="mobile" oninput="this.value = this.value.replace(/[^0-9]/g, ''); if (this.value.length > 10) this.value = this.value.slice(0, 10);" required style="color: white;">

            </div>
            <div class="form-group">
                <label for="email" style="color: white;">Email:</label>
                <input type="email" id="email" name="email" required  style="color: white;">
            </div>
            <div class="form-group">
                <label for="password" style="color: white;">Password:</label>
                <input type="password" id="password" name="password" required  style="color: white;">
            </div>
            <div class="form-group">
                
                <label for="Number" style="color: white;">Mpin:</label>
                <input type="text" id="Mpin" name="Mpin" pattern="\d{4}" maxlength="4" required  style="color: white;">
            </div>
            <div class="form-group">
                <button type="submit">Sign Up</button>
            </div>
            <div>
                <p style="color: white; justify-content: center;">Already have an Account? <a href="login_Page.php" style="color: white;">Login</a></p>

            </div>
        </form>
        <div id="message"></div>
    </div>
</div>

<?php include 'comman/auth_footer.php';
?>
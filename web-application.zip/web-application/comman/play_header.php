<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>How To Play</title>
    <style>
         body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }


        .container {
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border-radius: 0px;
            margin:  auto;
            max-width: 400px;
            position: relative;
            height: 540px;
        }

        
        .forgot-password-form {
            max-width: 400px;
            margin: 0 auto;
            text-align: center;
        }

        .button-container {
            margin-top: 20px;
            display: flex;
            justify-content: space-between;
        }

        .button-container button {
            flex: 1;
            padding: 10px;
            margin-right: 10px;
            border: none;
            border-radius: 230px;
            cursor: pointer;
            font-size: 16px;
            background-color: #a15b16;
            color: #fff;
        }

        button:hover {
            background-color: #a15b16;
        }

        .card-container {
            margin-top: 20px;
            display: flex;
            flex-direction: column;
        }


        .back-to-login {
            margin-top: 20px;
            color: #333;
        }

        .back-to-login a {
            color: #007bff;
            text-decoration: none;
        }

        .back-to-login a:hover {
            text-decoration: underline;
        }

        .logo {
            max-width: 100%;
            height: auto;
            margin-bottom: 20px;
            position: absolute;
            margin-top: -167px;
        }

        .abc {
            background-color: #702424;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: auto;
            max-width: 400px;
        }

        .abc {
            display: flex;
            align-items: center;
        }

        .back-icon {
            margin-right: 20px;
            cursor: pointer;
        }

       
    </style>
</head>

<body>
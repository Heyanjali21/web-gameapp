
<script>
    // JavaScript function to handle the redirection
    function redirectToPage(msg) {
        console.log('Message:', msg); // Debugging statement

        // Check if the message is available
        if (msg) {
            // Check the message content and redirect accordingly (case-insensitive)
            if (msg.toLowerCase() === 'market running') {
                console.log('Redirecting to sgkalyan.php'); // Debugging statement
                window.location.href = 'sgkalyan.php'; // Change 'index.php' to your actual index page URL
            } else {
                console.log('Message does not require redirection.'); // Debugging statement
                // Add additional conditions if needed for different messages
            }
        } else {
            console.log('Message not available.'); // Debugging statement
            // Optionally, provide feedback to the user or handle the case when the message is not available
        }
    }

    // Attach click event to all video links
    document.addEventListener('DOMContentLoaded', function () {
        var videoLinks = document.querySelectorAll('.video-link');

        videoLinks.forEach(function (link) {
            link.addEventListener('click', function () {
                var msg = this.getAttribute('data-msg');
                redirectToPage(msg);
            });
        });
    });
</script>







    </script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const menuIcon = document.getElementById("menu-icon");
            const mainMenu = document.getElementById("main-menu");

            menuIcon.addEventListener("click", function() {
                mainMenu.style.display = mainMenu.style.display === "none" ? "flex" : "none";
            });

            window.addEventListener("resize", function() {
                if (window.innerWidth > 768) {
                    mainMenu.style.display = "none";
                }
            });
        });
    </script>
    <script>
        // Get the share icon element
        var shareIcon = document.getElementById("share-icon");

        // Add a click event listener to the share icon
        shareIcon.addEventListener("click", function() {
            // URL to be shared
            var shareUrl = "main.html";

            // Text to be shared (optional)
            var shareText = "Check out this cool app on Satta!";

            // Construct platform-specific sharing links
            var whatsappLink = "whatsapp://send?text=" + encodeURIComponent(shareText + " " + shareUrl);
            var instagramLink = "https://www.instagram.com/share?url=" + encodeURIComponent(shareUrl);
            var facebookLink = "https://www.facebook.com/sharer/sharer.php?u=" + encodeURIComponent(shareUrl);
            var linkedinLink = "https://www.linkedin.com/shareArticle?url=" + encodeURIComponent(shareUrl);
            var telegramLink = "https://t.me/share/url?url=" + encodeURIComponent(shareUrl) + "&text=" + encodeURIComponent(shareText);

            // Open the sharing links in new tabs/windows
            window.open(whatsappLink);
            window.open(instagramLink);
            window.open(facebookLink);
            window.open(linkedinLink);
            window.open(telegramLink);
        });
    </script>

    <script>
        function openContactPage() {
            window.location.href = 'contacthome.html';
        }

        function play() {
            window.location.href = 'play.html';
        }
    </script>
    <script>
        function openNav() {
            document.getElementById("mySidepanel").style.width = "250px";
        }

        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }
    </script>
    <script>
        function goBackk() {
            window.location.href = 'main.html';
        }
    </script>

    <!-- for buuton -->
    <script>
        document.getElementById("bellButton").addEventListener("click", function() {
            window.location.href = "bell.html";
        });
    </script>


    <!-- for logout -->

    <script>
        function openModal() {
            console.log("Modal button clicked!");
            // rest of the code...
        }

        function openModal() {
            var modal = document.getElementById("myModal");
            var confirmYesBtn = document.getElementById("confirmYes");
            var confirmNoBtn = document.getElementById("confirmNo");

            modal.style.display = "block";

            confirmYesBtn.onclick = function() {
                window.location.href = "loginpage.php";
            };

            confirmNoBtn.onclick = function() {
                modal.style.display = "none";
            };

            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                }
            };
        }
    </script>




</body>

</html>
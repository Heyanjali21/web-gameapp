<?php
include 'db_connection.php'; // Include your database connection script

// Verify the Razorpay payment response (you may need to customize this part)
$razorpay_payment_id = $_POST['razorpay_payment_id'];
$amount = $_POST['amount'];

// Insert the payment details into the transaction_history table
$insertQuery = "INSERT INTO transaction_history (transaction_id, amount, date_time) VALUES ('$razorpay_payment_id', $amount, NOW())";

if ($mysqli->query($insertQuery)) {
    // Redirect to wallet_page.php with a success message
    header("Location:  wallet_page.php?status=success");
    exit();
} else {
    echo "Error saving payment details: " . $mysqli->error;
}

$mysqli->close();
?>

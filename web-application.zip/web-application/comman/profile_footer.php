<script>
        function goBack() {
            window.location.href = 'profile_page.php'; 
        }
    </script>
    
    
 <!-- for display api response -->

<script>
    function submitForm() {
        var form = document.getElementById("profileForm");
        var formData = new FormData(form);

        // Make an AJAX request to your PHP script
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "edit_profile_api.php", true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                // Parse the JSON response
                var jsonResponse = JSON.parse(xhr.responseText);

                // Display the "msg" in the specified container
                document.getElementById("apiResponseContainer").innerHTML = jsonResponse.msg;
            }
        };

        xhr.send(formData);
    }
</script>

</body>

</html>

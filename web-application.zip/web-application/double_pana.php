<?php include 'comman/pana_header.php';
?>

<div class="abc">
    <span class="back-icon" onclick="goBack()">&#8592;</span>
    <h2>Double Pana</h2>
</div>
<div class="container">
    <div class="centered-content">
        <!-- for current date -->
        <?php
        $apiUrl = 'https://disawar.techwarezen.shop/admin/api-get-current-date';

        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);


        $requestBody = json_encode([
            'env_type' => 'Prod',
            'app_key' => 'HbegvJLeKwSFyApopniGHHBTZPocyH',
            'unique_token' => isset($_COOKIE['localDataStore']) ? $_COOKIE['localDataStore'] : '',
            'game_id' => 3,  // Replace with the actual game ID
        ]);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $requestBody);


        $headers = [
            'Content-Type: application/json',
        ];
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Curl error: ' . curl_error($ch);
        }
        curl_close($ch);
        $data = json_decode($response, true);
        if ($data !== null && isset($data['status']) && $data['status']) {
            echo $data['new_date'];
        } else {
            echo 'Error decoding JSON response or data not available.';
        }
        ?>
    </div>


    <form class="con" id="myForm" onsubmit="event.preventDefault(); validateAndSubmitForm();">
        <button class="option-button" onclick="handleOption('open')">
            <span><input type="radio" name="status" value="open" style="margin-left: -51%;"></span>Open
        </button>
        <button class="option-button" onclick="handleOption('close')">
            <span><input type="radio" name="status" value="close" style="margin-left: -51%;"></span>Close
        </button>

        <div class="form-group">
            <label for="amount" id="labelForAmount">Close Digit</label>
            <input type="text" id="amount" name="amount" placeholder="Enter Digit" maxlength="3" oninput="suggestDigits(this.value)" required>
            <span id="amountError" style="color: red;"></span>
            <div id="suggestionsContainer">
                <div id="suggestions"></div>
            </div>
        </div>

        <div class="form-group">
            <label for="number">Points</label>
            <input type="number" id="number" name="number" placeholder="Enter Points" required min="10">
            <span id="error-message" style="color: red;"></span>
        </div>

        <button type="button" class="button" onclick="validateAndSubmitForm()">PROCEED</button>

        <table id="dataTable" border="1" style="display:none;">
            <thead>
                <tr>
                    <th>Status</th>
                    <th>Close Digit</th>
                    <th>Points</th>
                </tr>
            </thead>
            <tbody id="dataBody"></tbody>
        </table>

        <button type="button" id="showDataBtn" style="display:none;" onclick="submitForm()">Submit</button>
        <!--<div class="api" style="margin-top: 20px;">-->
        <!--    <div id="apiResponseContainer"></div>-->
        <!--</div>-->
    </form>


    <?php include 'comman/double_pana_footer.php';
    ?>

<?php include 'comman/phonepe_header.php';
?>
<div class="container">
    <div class="card">
    <img src="https://disawar.techwarezen.shop/web-app/assets/img/paytm.png"
         style="height: 30px; margin-top: 10px; margin-left: -113px; border-radius: 20px;">
        <h3 style="margin-top: -28px;">PhonePe</h3>
    </div>
    <div class="input-container">
        <label for="numberInput" style="margin-left: -35%;">Add PayTm Number</label>
        <input type="number" placeholder="Enter number" id="numberInput">
    </div>
    <div class="button-container">
        <button onclick="moveLeft()">CANCEL</button>
        <button onclick="moveRight()">SUBMIT</button>
    </div>
</div>


<?php include 'comman/phonepe_footer.php';
?>
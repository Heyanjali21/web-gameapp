<script>
        function goBack() {
            window.location.href = 'change_password.php'; 
        }
    </script>
</body>

</html>

<script>
        function goBack() {
            window.location.href = 'home.php'; 
        }
    </script>

</body>

</html>
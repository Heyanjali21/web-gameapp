<script>
    function validatePassword(password) {
        // Check if the password contains at least 1 digit or 1 special character
        // and has a minimum length of 6 and a maximum length of 10
        var regex = /^(?=.*\d)(?=.*[!@#$%^&*()_+])[0-9a-zA-Z!@#$%^&*()_+]{6,10}$/;
        return regex.test(password);
    }

    function changePassword() {
        var oldPassword = document.getElementById('oldPassword').value;
        var newPassword = document.getElementById('newPassword').value;
        var confirmPassword = document.getElementById('confirmPassword').value;

        // Validate the new password
        if (!validatePassword(newPassword)) {
            document.getElementById('message').innerHTML = "Password must contain at least 1 digit or 1 special character and be 6 to 10 characters long.";
            return;
        }

        // Additional validation and form submission logic can be added here

        // Submit the form if all validations pass
        document.getElementById('changePasswordForm').submit();
    }
</script>

<script>
        function goBack() {
            window.location.href = 'profile_page.php'; 
        }
    </script>
    
    
    <!--display api response-->

<script>
    function submitForm() {
        var form = document.getElementById("changePasswordForm");
        var formData = new FormData(form);

        // Make an AJAX request to your PHP script
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "change_pass_api.php", true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                // Parse the JSON response
                var jsonResponse = JSON.parse(xhr.responseText);

                // Display the "msg" in the specified container
                document.getElementById("apiResponseContainer").innerHTML = jsonResponse.msg;
            }
        };

        xhr.send(formData);
    }
</script>
</body>

</html>

<?php
if (!isset($_COOKIE['localDataStore'])) {
    header("Location: login_page.php");
    exit();
}
?>

<?php include 'comman/main_header.php';
?>
<div id="mySidepanel" class="sidepanel">
    <div class="profile-containerr">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
        <div id="menu-icon"><i class="fas fa-bars"></i></div>


        <!-- for profile -->
        <a href="profile_page.php">
            <div >
                <?php
                $apiUrl = 'https://disawar.techwarezen.shop/admin/api-get-profile';

                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                }

                $uniqueToken =  isset($_COOKIE['localDataStore']) ? $_COOKIE['localDataStore'] : '';

                $tokenData = array(
                    "env_type" => "Prod",
                    "app_key" => "HbegvJLeKwSFyApopniGHHBTZPocyH",
                    "unique_token" => $uniqueToken,
                );

                //  echo $uniqueToken;
                $tokenJson = json_encode($tokenData);

                $ch = curl_init($apiUrl);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $tokenJson);
                curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

                $response = curl_exec($ch);

                if ($response === false) {
                    echo '<tr><td colspan="4">Error: Unable to fetch data from the API. cURL error: ' . curl_error($ch) . '</td></tr>';
                } else {
                    $data = json_decode($response, true);
                    if (isset($data['status']) && $data['status']) {
                        if (isset($data['profile'])) {
                            $resultData = $data['profile'][0];
                ?>


                            <img src="https://disawar.techwarezen.shop/web-app/assets/img//profile.jpeg" alt="Profile Logo" class="profile-logo">
                            <div> <?php echo $resultData["mobile"]; ?> </div>
                            <div> <?php echo $resultData["user_name"]; ?> </div>
                <?php
                        } else {
                            echo '<tr><td colspan="4">Error: Profile key is missing in the API response.</td></tr>';
                        }
                    } else {
                        echo '<tr><td colspan="4">Error: ' . $data['msg'] . '</td></tr>';
                    }
                }

                curl_close($ch);
                ?>
            </div>
        </a>


        <!-- End of profile -->
        
    </div class="bb">
    <a href="home.php" class="icon-with-text"><i class="fas fa-home"></i>Home</a>
    <a href="profile_page.php" class="icon-with-text"><i class="fas fa-user"></i>My Profile</a>
    <a href="wallet_page.php" class="icon-with-text"><i class="fas fa-wallet"></i>Wallet</a>
    <a href="win_history.php" class="icon-with-text"><i class="fas fa-trophy"></i>Win History</a>
    <a href="bid_history.php" class="icon-with-text"><i class="fas fa-gavel"></i>Bid History</a>
    <a href="how_play.php" class="icon-with-text"><i class="fas fa-play"></i>How To Play</a>
    <a href="#" class="icon-with-text"><i class="fas fa-star"></i>Games Rates</a>
    <a href="#" class="icon-with-text"><i id="share-icon" class="fas fa-share-alt"></i>Share</a>
    <a href="contact_page.php" class="icon-with-text"><i class="fas fa-question-circle"></i>Help Center</a>
    <a href="https://play.google.com/store/apps/details?id=your.package.name" class="icon-with-text" target="_blank">
        <i class="fas fa-star"></i>Ratings
    </a>
    <a href="admin_notice.php" class="icon-with-text"><i class="fas fa-bullhorn"></i>Admin Notice</a>
    <a href="#" onclick="openModal()"><button class="bttn">LOGOUT</button></a>

    <!-- Modal -->
    <div id="myModal" class="modal">
        <div class="modal-content">
            <p style="color: white;">Are you sure you want to logout?</p>
            <button id="confirmYes" class="btt">Yes</button>
            <button id="confirmNo" class="btt">No</button>
        </div>
    </div>
    <!--<a href="logout.html" onclick="openModal()"><button class="btn" style="color: white;">LOGOUT</button></a>-->
</div>

<div class="btn">
    <button class="openbtn" onclick="openNav()">☰</button>

    <div class="noti">
        <a href="notification_page.php"> <button class="bell-button bell-icon" id="bellButton"><i class="fas fa-bell"></i></button></a>
    </div>
</div>

<!-- slider image -->

<div class="profile-container">
    <div class="slider">
        <?php
        $apiUrl = 'https://disawar.techwarezen.shop/admin/api-get-slider-images';

        $postData = json_encode([
            'env_type' => 'Prod',
            'app_key' => 'HbegvJLeKwSFyApopniGHHBTZPocyH',
            'unique_token' => '4AR6tSuQEquKeUL7Uwh1ZnkaJz0vrK'
        ]);

        $options = [
            'http' => [
                'header' => "Content-type: application/json\r\n",
                'method' => 'POST',
                'content' => $postData,
            ],
        ];

        $context = stream_context_create($options);
        $response = file_get_contents($apiUrl, false, $context);

        if ($response !== false) {
            $data = json_decode($response, true);

            if ($data['status'] && isset($data['sliderdata'])) {
                foreach ($data['sliderdata'] as $image) {
                    $maxWidth = 300; 
                    $maxHeight = 104;

                    echo '<div class="slide"><img src="' . $image['slider_image'] . '" alt="Slider Image" style="max-width: ' . $maxWidth . 'px; max-height: ' . $maxHeight . 'px;"></div>';
                }
            } else {
                echo 'No slider images available.';
            }
        } else {
            echo 'Error fetching data from the API.';
        }
        ?>
    </div>
</div>

<!-- End of slider image -->

<!-- dipaly game in cards -->
<div class="main-container">
    <div class="button-container">
        <button class="button button-left" onclick="openContactPage()">CONTACT US</button>
        <button class="button button-left" onclick="play()">HOW TO PLAY</button>
    </div>

    <div class="card-container">
        <?php
        $apiUrl = 'https://disawar.techwarezen.shop/admin/api-get-dashboard-data';
        $selectedDate = "";
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        }
        $tokenData = array(
            "env_type" => "Prod",
            "app_key" => "HbegvJLeKwSFyApopniGHHBTZPocyH",
            "unique_token" => "4AR6tSuQEquKeUL7Uwh1ZnkaJz0vrK"
        );


        $tokenJson = json_encode($tokenData);

        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $tokenJson);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

        $response = curl_exec($ch);

        if ($response === false) {
            echo '<tr><td colspan="4">Error: Unable to fetch data from the API. cURL error: ' . curl_error($ch) . '</td></tr>';
        } else {
            $data = json_decode($response, true);

            if ($data === null || !isset($data['result'])) {
                echo '<tr><td colspan="4">Error: Failed to parse JSON data or missing "result" data.</td></tr>';
            } else {

                $resultData = $data['result'];


                // Pagination logic
                $perPage = 10;
                $totalResults = count($resultData);
                $currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;

                // Calculate total pages
                $totalPages = ceil($totalResults / $perPage);

                // Validate current page
                if ($currentPage < 1) {
                    $currentPage = 1;
                } elseif ($currentPage > $totalPages) {
                    $currentPage = $totalPages;
                }

                // Iterate over the data and display cards
                foreach ($resultData as $row) {
                    // $gameId = $row['game_id'];

        ?>
                    <div class="card">
                        <h5 class="card-title name-ico"><?php echo $row['game_name']; ?></h5>
                        <p class="card-text" style="color: red;"><?php echo $row['game_id']; ?></p>
                        <p class="card-text" style="color: red;"><?php echo $row['msg']; ?></p>
                        <p class="card-text center-text" style="color: green;">Open Bids:
                        <p style="color: green;" class="time"><?php echo $row['open_time']; ?></p>
                        </p>
                        <p class="card-text center-textt" style="color: red;">Close Bids:
                        <p style="color: red;" class="time"><?php echo $row['close_time']; ?></p>
                        </p>
                        <!-- Add a link around the video icon with data-msg attribute -->
                          <a href="javascript:void(0);" class="video-link" data-msg="<?php echo strtolower($row['msg']); ?>" data-game-id="<?php echo $row['game_id']; ?>" data-game-name="<?php echo $row['game_name']; ?>">
                            <img src="https://disawar.techwarezen.shop/web-app/assets/img/video.png" alt="Video Icon" class="video-icon">
                        </a>
                        <img src="https://disawar.techwarezen.shop/web-app/assets/img/alram.png" alt="Video Icon" class="video-ii">
                    </div>
        <?php
                }
            }
        }

        curl_close($ch);
        ?>
    </div>
</div>

 <!-- Ends of cards -->

<?php include 'comman/main_footer.php';
?>
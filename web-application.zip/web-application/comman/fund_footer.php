<!--  -->

<script>
    function goBack() {
        window.location.href = 'wallet_page.php';
    }
</script>
<script>
    function redirectToPhonePe() {
        // Replace the URL with the actual PhonePe payment URL
        window.location.href = 'https://www.phonepe.com/';
    }

    function redirectToGooglePay() {
        // Replace the URL with the actual GooglePay payment URL
        window.location.href = 'https://pay.google.com/';
    }

    function redirectToOther() {
        // Replace the URL with the actual URL for other payment method
        window.location.href = 'https://www.example.com/other-payment';
    }
</script>

<script>
        var rzp = new Razorpay(options);
        
        function redirectToPhonePe() {
            // Handle PhonePe redirection logic here
            rzp.open();
        }
        
        function redirectToGooglePay() {
            // Handle Google Pay redirection logic here
            rzp.open();
        }
        
        function redirectToOther() {
            // Handle Other payment redirection logic here
            rzp.open();
        }
    </script>
   <script>
     function updateAmount() {
        // Your existing updateAmount function
    }

    // Additional JavaScript code for handling Razorpay payment success
    var options = {
        key: "<?php echo $apiKey; ?>",
        amount: "<?php echo $amount * 100; ?>", // Amount in paisa
        name: "Techwarazen",
        handler: function (response) {
            // When the payment is successful, submit the form
            document.getElementById('payment-form').submit();
        },
        prefill: {
            name: "John Doe",
            email: "john@example.com",
            contact: "1234567890"
        }
    };

    var rzp1 = new Razorpay(options);
   </script>
</body>

</html>
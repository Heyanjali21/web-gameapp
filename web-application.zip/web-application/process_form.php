<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // API endpoint
    $apiUrl = 'https://disawar.techwarezen.shop/admin/api-submit-bid';

    // Form data
    $status = isset($_POST['status']) ? $_POST['status'] : '';
    $amount = isset($_POST['amount']) ? $_POST['amount'] : '';
    $points = isset($_POST['number']) ? $_POST['number'] : '';
    $uniqueToken = isset($_COOKIE['localDataStore']) ? $_COOKIE['localDataStore'] : '';
    $game_id = isset($_COOKIE['game_id']) ? $_COOKIE['game_id'] : '';
    $game_name = isset($_COOKIE['game_name']) ? $_COOKIE['game_name'] : '';

    // Get the current date
    $currentDate = date('Y-m-d');

    // Dynamic 'pana' value based on your game logic
    $pana = getDynamicPanaValue(); // Implement this function based on your logic

    // Prepare data for API request
    $apiData = [
        'app_key' => 'HbegvJLeKwSFyApopniGHHBTZPocyH',
        'env_type' => 'Prod',
        'new_result' => [
            'unique_token' => $uniqueToken,
            'gameid' => $game_id,
            'Gamename' => $game_name,
            'pana' => $pana,
            'bid_date' => $currentDate, 
            'totalbit' => 100,
            'session' => $status,
            'result' => [
                [
                    'session' => $status,
                    'digits' => '',
                    'closedigits' => $amount,
                    'points' => $points,
                ],
            ],
        ],
    ];

    // Make API request
    $ch = curl_init($apiUrl);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($apiData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Execute cURL session and get the response
    $response = curl_exec($ch);

    // Check for errors
    if (curl_errno($ch)) {
        echo 'Curl error: ' . curl_error($ch);
    } else {
        // Output the API response
        echo $response;
    }

    // Close cURL session
    curl_close($ch);
} else {
    // Handle non-POST requests
    echo json_encode(['status' => false, 'msg' => 'Invalid request method']);
}

function getDynamicPanaValue() {
    return 'Dynamic Pana';
}
?>

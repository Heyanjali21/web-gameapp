<?php include 'comman/wallet_header.php';
?>


<div class="abc">
    <span class="back-icon" onclick="goBack()">&#8592;</span>
    <h2>Wallet</h2>
</div>

<!-- for virtical card -->
<div class="container">
    <form id="profileForm" action="wallet.php" method="POST">
        <div class="card-container">
            <div class="card">
                <img src="https://disawar.techwarezen.shop/web-app/assets/img/refresh.png" alt="Refresh" class="refresh-icon" onclick="fetchWalletAmount()">
                <h3 id="walletAmount" style="margin-left: 15px; margin-top: 10px;">Total Balance</h3>

                <?php
                // Fetch wallet details
                $api_url = 'https://disawar.techwarezen.shop/admin/api-wallet-transaction-history';
                $uniqueToken = isset($_COOKIE['localDataStore']) ? $_COOKIE['localDataStore'] : '';
                $data = array(
                    "env_type" => "Prod",
                    "app_key" => "HbegvJLeKwSFyApopniGHHBTZPocyH",
                    "unique_token" => $uniqueToken,
                );

                $options = array(
                    'http' => array(
                        'header' => "Content-type: application/json",
                        'method' => 'POST',
                        'content' => json_encode($data),
                    ),
                );

                $context = stream_context_create($options);
                $response = file_get_contents($api_url, false, $context);
                $walletDetails = json_decode($response, true);

                // Display wallet details
                if ($walletDetails['status'] === true) {
                    echo '<p><span style=" font-weight: bold; margin-left: 15px;">' . $walletDetails['wallet_amt'] . '</span></p>';
                } else {
                    echo '<p style="color: red;">Error fetching wallet details</p>';
                }
                ?>

            </div>
        </div>

        <!-- for horizontal card -->

        <div class="con">
            <div class="card-con">
                <div class="cardd">
                    <div class="test">
                        <img src="https://disawar.techwarezen.shop/web-app/assets/img/e.png" alt="Image">
                    </div>
                    <h3>Transfer Money</h3>
                </div>
            </div>
            <div class="card-con">
                <div class="cardd">
                    <div class="test">
                        <a href="add_fund.php">
                            <img src="https://disawar.techwarezen.shop/web-app/assets/img/addmoney.png" alt="Image"></a>
                    </div>
                    <h3>Add Money</h3>
                </div>
            </div>
            <div class="card-con">
                <div class="cardd">
                    <div class="test">
                        <a href="withdraw.php">
                            <img src="https://disawar.techwarezen.shop/web-app/assets/img/withdraw.png" alt="Image"></a>
                    </div>
                    <h3>Withdraw Money</h3>
                </div>
            </div>
            <div class="card-con">
                <div class="cardd">
                    <div class="test">
                        <a href="googlepay.php">
                            <img src="https://disawar.techwarezen.shop/web-app/assets/img/gpay.png" alt="Image"></a>
                    </div>
                    <h3>Add GooglePay</h3>
                </div>
            </div>
            <div class="card-con">
                <div class="cardd">
                    <div class="test">
                        <a href="phonepe.php">
                            <img src="https://disawar.techwarezen.shop/web-app/assets/img/phonepe.png" alt="Image"></a>
                    </div>
                    <h3>Add Phonepe</h3>
                </div>
            </div>
            <div class="card-con">
                <div class="cardd">
                    <div class="test">
                        <a href="paytm.php">
                            <img src="https://disawar.techwarezen.shop/web-app/assets/img/paytm.png" alt="Image"></a>
                    </div>
                    <h3>Add Paytm</h3>
                </div>
            </div>

        </div>
        <!-- handle_payment.php -->
        <?php
// Fetch wallet details
$api_url = 'https://disawar.techwarezen.shop/admin/api-wallet-transaction-history';
$uniqueToken = isset($_COOKIE['localDataStore']) ? $_COOKIE['localDataStore'] : '';
$data = array(
    "env_type" => "Prod",
    "app_key" => "HbegvJLeKwSFyApopniGHHBTZPocyH",
    "unique_token" => $uniqueToken,
);

$options = array(
    'http' => array(
        'header' => "Content-type: application/json",
        'method' => 'POST',
        'content' => json_encode($data),
    ),
);

$context = stream_context_create($options);
$response = @file_get_contents($api_url, false, $context); // Using @ to suppress warnings
$walletDetails = json_decode($response, true);

// Display wallet details and transaction history
if ($walletDetails !== null && isset($walletDetails['status']) && $walletDetails['status'] === true) {
    ?>
    <h3>Transaction History</h3>
        <?php
        if (!empty($walletDetails['transaction_history'])) {
            ?>
                <?php
                foreach ($walletDetails['transaction_history'] as $transaction) {
                    ?>
                     <div class="card">
                        
                                <p style="margin-left: 15px; margin-top: 7px;"><?php echo date('Y-m-d', strtotime($transaction['insert_date'])); ?></p><br>
                                <p style="margin-left: 15px; margin-top: -26px;"><?php echo date('h:i A', strtotime($transaction['insert_date'])); ?></p><br>
                                <p style="margin-left: 15px; margin-top: -27px;"><?php echo htmlspecialchars($transaction['transaction_note']); ?></p><br>
                    
                        </div>
                    <?php
                }
                ?>
            <?php
        } else {
            ?>
            <p style="margin-left: 15px;">No transaction history available.</p>
            <?php
        }
        ?>
    </div>
    <?php
} else {
    // Add more specific error handling based on the possible error scenarios
    $errorMessage = $walletDetails !== null ? 'Error fetching wallet details: ' : 'Unable to connect to the API.';
    echo '<p style="color: red;">' . $errorMessage . '</p>';
}
?>
    </form>
    <div id="message"></div>
</div>


<?php include 'comman/wallet_footer.php';
?>
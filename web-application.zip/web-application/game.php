<?php include 'comman/game_page_header.php';
?>


<div class="abc">
    <span class="back-icon" onclick="goBack()">&#8592;</span>
    <h2>sgkalyan</h2>
</div>
<div class="container">
    <div class="card" style="background-color: rgb(253, 253, 162);">
        <a href="single_digit.php"><img src="https://disawar.techwarezen.shop/web-app/assets/img/ludo.png" alt="Image"></a>
        <p>Single Digit</p>
    </div>

    <div class="card" style="background-color: rgb(243, 243, 110);">
        <?php
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);

        $apiUrl = 'https://disawar.techwarezen.shop/admin/api-check-game-status';

        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $requestBody = json_encode([
            'env_type' => 'Prod',
            'app_key' => 'HbegvJLeKwSFyApopniGHHBTZPocyH',
            'unique_token' => isset($_COOKIE['localDataStore']) ? $_COOKIE['localDataStore'] : '',
            'game_id' => isset($_COOKIE['game_id']) ? $_COOKIE['game_id'] : '',
            'game_name' => isset($_COOKIE['game_name']) ? $_COOKIE['game_name'] : '',

        ]);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $requestBody);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);

        $headers = [
            'Content-Type: application/json',
        ];
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Curl error: ' . curl_error($ch) . ' (' . curl_errno($ch) . ')';
        } else {
            $data = json_decode($response, true);
            if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
                echo 'Error decoding JSON response: ' . json_last_error_msg();
            } else {
                if (isset($data['game_status']) && isset($data['msg'])) {
                    if ($data['game_status'] == 1) {
                    } elseif ($data['game_status'] == 2) {
                    }
                } else {
                    echo 'Error: Key "game_status" or "msg" not found in the response.';
                }
            }
        }

        curl_close($ch);
        ?>


    
            <a href="#" onclick="fetchPana('jodi_digit.php')"><img src="http://localhost/application/assets/img/ludoo.png" alt="Image"></a>
            <p id="gameStatusText">Jodi Digit</p>
        
    </div>
    <!-- Second Line -->
    <div class="card" style="background-color: plum;">
        <a href="#" onclick="fetchPana('single_pana.php')"><img src="https://disawar.techwarezen.shop/web-app/assets/img/card.png" alt="Image"></a>
        <p>Single Panna</p>
    </div>

    <div class="card" style="background-color: rgb(103, 213, 103);">
        <a href="#" onclick="fetchPana('double_pana.php')"><img src="https://disawar.techwarezen.shop/web-app/assets/img/card.png" alt="Image"></a>
        <p>Double Panna</p>
    </div>

    <!-- Third Line -->
    <div class="card" style="background-color: rgb(136, 182, 136);">
        <a href="#" onclick="fetchPana('tripal_pana.php')"><img src="https://disawar.techwarezen.shop/web-app/assets/img/card.png" alt="Image"></a>
        <p>Triple Panna</p>
    </div>

    <div class="card" style="background-color: rgb(151, 151, 206);" id="myCard">
        <a href="#" onclick="fetchPana('half_sangam.php')"><img src="https://disawar.techwarezen.shop/web-app/assets/img/card.png" alt="Image"></a>
        <p>Half Sangam</p>
    </div>


    <div class="cardd" style="background-color: rgb(250, 99, 17);">
        <a href="#" onclick="fetchPana('full_sangam.php')"> <img src="https://disawar.techwarezen.shop/web-app/assets/img/ludo.png" alt="Image"></a>
        <p>Full Sangam</p>
    </div>
</div>
<div id="message"></div>
<script>
    function fetchPana(page) {
        if (page && page.trim() !== '') {
            window.location.href = page;
        } else {
            console.error('Invalid page parameter');
        }
    }
</script>
<?php include 'comman/game_page_footer.php';
?>
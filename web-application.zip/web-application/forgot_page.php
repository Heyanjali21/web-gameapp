
<?php include 'comman/auth_header.php';
?>

<div style="color: black;">
        <div class="profile-container">
            <img src="https://disawar.techwarezen.shop/web-app/assets/img/logo.png" alt="Profile Logo" class="profile-logo">
        </div>
        <div class="forgot-container">
            <form id="pass" class="forgot-password-form">
                <h2 style="color: white;">Forgot Password</h2>
                <input type="tel" id="mobile" name="mobile" placeholder="Phone Number" required  style="color: white;">
                <button type="submit">SUBMIT</button>
            </form>
            <div id="message"></div>
        </div>
    </div>

    <?php include 'comman/auth_footer.php';
?>
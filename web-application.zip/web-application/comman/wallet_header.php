<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wallet</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-qh8Xz5g+5+pru3AKbBxyTsvYZJTRs/46g2hghT8cF4vj84Qw4rcq5egxxjczD2hpjli4ItRVr7YqNJo6ikfCA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        /* @media only screen and (max-width: 600px) {
            body {
                padding: 0 10px;
            }
        } */

        /* Media query for medium-sized screens */
        @media only screen and (min-width: 601px) and (max-width: 1024px) {
            body {
                padding: 0 30px;
            }
        }

        /* Media query for larger screens */
        @media only screen and (min-width: 1025px) {
            body {
                padding: 0 50px;
            }
        }

        .container {
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border-radius: 0px;
            margin: auto;
            max-width: 400px;
            position: relative;
            overflow-x: hidden;
        }

        .card-container {
            margin-top: 20px;
            display: flex;
            flex-direction: column;
        }

        .card {
            background-color: white;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 20px;
            margin-bottom: 25px;
            height: 95px;
            width: auto;
            border: 4px solid brown;
        }
        
@media not all and (min-resolution: 0.001dpcm) {
    .card {
        background-color: #fff;
         width: 100%;

    }
}

        .formate
        {
            background-color: white;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 20px;
            margin-bottom: 10px;
            height: 108px;
            width: auto;
            border: 4px solid brown;
        }
        .result
        {
            background-color: white;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 20px;
            margin-bottom: 10px;
            height: 145px;
            width: auto;
            border: 4px solid brown;
        }
        .logo {
            max-width: 100%;
            height: auto;
            margin-bottom: 20px;
            position: absolute;
            margin-top: -167px;
        }

        .abc {
            background-color: #702424;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: auto;
            max-width: 400px;
        }

        .abc {
            display: flex;
            align-items: center;
        }

        .back-icon {
            margin-right: 20px;
            cursor: pointer;
        }

        .form-group button {
            background-color: rgb(152, 53, 69);
            color: white;
            padding: 10px;
            border: none;
            border-radius: 20px;
            cursor: pointer;
            font-size: 10px;
            width: 60%;
            margin-left: 20%;
            margin-bottom: 100%;
        }

        .con {
            display: flex;
            overflow-x: auto;
            white-space: nowrap;
            margin-bottom: 15px;
        }

        .card-con {
            display: flex;
            justify-content: space-around;
            align-items: center;
        }

        .cardd {
            background-color: #ffffff;
            border: 4px solid brown;
            border-radius: 8px;
            padding: 10px;
            margin: 10px;
            width: 80px;
            height: 120px;
            margin-top: 30px;
        }

        .cardd img {
            max-width: 49%;
            max-height: 50%;
            border-radius: 60%;
            margin-left: 16px;
            margin-top: 14px;

        }

        .test {
            background-color: #ff8600;
            border-radius: 54px;
            width: 60px;
            height: 59px;
            border: 5px solid brown;
            margin-bottom: 30px;
        }

        .cardd h3 {
            color: black;
            font-size: 10px;
        }

        .containerr {
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border-radius: 8px;
            position: relative;
            width: 100%;
        }

        .card-conn {
            margin-top: 20px;
            display: flex;
            flex-direction: column;
        }

        .c {
            background-color: white;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 20px;
            margin-bottom: 10px;
            height: 80px;
            width: 100%;
            border: 2px solid brown;
        }

        .card {
            position: relative;
        }

        .refresh-icon {
            position: absolute;
            top: 0;
            right: 0;
            cursor: pointer;
            height: 30px;
            margin-top: 20px;
            margin-right: 10px;
        }
    </style>
</head>

<body>
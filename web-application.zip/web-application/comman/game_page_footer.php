<script>
  function goBack() {
    window.location.href = 'home.php';
  }
</script>


<script>
  $(document).ready(function() {
    $("#profileForm").submit(function(e) {
      e.preventDefault();

      var formData = $(this).serialize();

      $.ajax({
        type: "POST",
        url: "sgkalyanapi.php",
        data: formData,
        success: function(response) {
          $("#message").html(response);
        }
      });
    });
  });
</script>

<script>
  function handleLinkClick(event) {

    event.preventDefault();
    <?php if (isset($data['game_status']) && $data['game_status'] == 2) { ?>
      alert("Betting is closed. Please check back later.");
    <?php } else { ?>

      window.location.href = "<?php echo $jodiDigitLink; ?>";
    <?php } ?>
  }
</script>


<script>
  function showBettingClosedPopup() {
    alert("Betting is closed. Please check back later.");
  }
</script>';
</body>

</html>
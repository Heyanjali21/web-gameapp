
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <!-- ... other head elements ... -->
    <title>main page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        /* header {
            background-color: white;
            color: #fff;
            padding: 20px;
            text-align: center;
            position: relative;
        } */

        #menu-icon {
            display: none;
            /* Initially hide on larger screens */
            position: absolute;
            top: 20px;
            left: 20px;
            cursor: pointer;
            font-size: 20px;
        }

        .main-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
        }

        .button-container {
            display: flex;
            justify-content: space-between;
            width: 100%;
            max-width: 400px;
            margin-top: 20px;
        }

        .button {
            background-color: #a14837;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 15px;
            cursor: pointer;
            font-size: 16px;
            flex: 1;
            margin: 0 5px;
        }

        .card-container {
            overflow-y: auto;
            overflow-x: hidden;
            /*max-height: 422px;*/
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
            margin-top: 20px;
        }

        /* Hide the scrollbar for webkit (Chrome, Safari) */
        .card-container::-webkit-scrollbar {
            width: 0.5em;
        }

        .card-container::-webkit-scrollbar-thumb {
            background-color: #a14837;
            /* You can change the color to match your design */
            outline: 1px solid #7b0323;
            /* You can change the color to match your design */
        }

        .card-container::-webkit-scrollbar-track {
            background-color: #fff;
            /* You can change the color to match your design */
        }

        .card {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 50px;
            padding: 30px;
            margin-bottom: 10px;
            width: 100%;
            max-width: 300px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            height: 70px;
        }

@media not all and (min-resolution: 0.001dpcm) {
    .card {
        background-color: #fff;
         width: 100%;
        /* Add any other necessary styles */
    }
}
        .menu {
            display: none;
            flex-direction: column;
            align-items: center;
            position: absolute;
            top: 70px;
            left: 20px;
            background-color: #3498db;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 10px;
        }

        .menu-item {
            color: #fff;
            margin: 5px;
            cursor: pointer;
        }

        .sidepanel {
            height: 100%;
            width: 250px;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #111;
            overflow-x: hidden;
            padding-top: 60px;
            transition: 0.5s;
            overflow-y: auto;
        }


        .sidepanel a {
            padding: 8px 8px 8px 32px;
            text-decoration: none;
            font-size: 17px;
            color: white;
            display: block;
            transition: 0.3s;
            padding: 13px;
        }

        .sidepanel a:hover {
            color: #f1f1f1;
        }

        .sidepanel .closebtn {
            position: absolute;
            top: 0;
            right: 25px;
            font-size: 36px;
        }

        .openbtn {
            font-size: 20px;
            cursor: pointer;
            background-color: #7b0323;
            color: white;
            padding: 10px 15px;
            border: none;
        }

        .openbtn:hover {
            background-color: #444;
        }

        #menu-icon {
            display: none;
            /* Initially hide on larger screens */
            position: absolute;
            top: 20px;
            left: 20px;
            cursor: pointer;
            font-size: 20px;
        }

        .icon-with-text {
            display: flex;
            align-items: center;
        }

        .icon-with-text i {
            margin-right: 10px;
            /* Adjust the margin as needed */
        }

        .profile-logo {
            max-width: 100%;
            height: 60px;
            margin: 14px;
            border-radius: 30px;
            margin-top: auto;
        }

        .profile-container {
            text-align: center;
        }

        .profile-img {
            max-width: 100%;
            height: 80px;
            margin: 40px;
            border-radius: 20px;
        }

        .bell-button {
            background-color: #a14837;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 15px;
            cursor: pointer;
            font-size: 16px;
            margin-left: 270px;
        }

        #mySidepanel {
            background-color: #7b0323;
            overflow-x: hidden;
            overflow-y: auto;

        }

        .btn {
            background-color: #7b0323;
            display: flex;
            justify-content: space-between;
            padding: 0px 10px;
            margin-bottom: 10px;
        }

        .video-icon {
            float: right;
            width: 24px;
            height: 24px;
            margin-top: -90px;
        }

        .video-ii {
            display: flex;
            justify-content: center;
            align-items: center;
            ;
            width: 24px;
            height: 24px;
            margin-top: -90px;
            margin-left: 140px;
        }

        .center-text {
            text-align: right;
            margin-top: -112px;
            margin-right: 50px;
        }

        .time {
            text-align: right;
            margin-top: -10px;
            margin-right: 50px;
        }

        .center-textt {
            text-align: right;
            margin-right: 50px;
        }

        .name-ico {
            text-align: left;
            color: #7b0323;
            margin-top: -10px;
        }

        .profile-containerr {
            background-color: #a14837;
            margin-top: -60px;

        }

        .bb {
            padding-top: 50px;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0, 0, 0);
            background-color: rgba(0, 0, 0, 0.4);
            padding-top: 60px;
        }

        .modal-content {
            background-color: #a14837;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 35%;
        }

        .bttn {
            color: white;
            background-color: #a14837;
            padding: 10px 15px;
            margin: 5px;
            border: none;
            border-radius: 20px;
            cursor: pointer;
        }

        .btt {
            color: white;
            background-color: #7b0323;
            padding: 10px 15px;
            margin: 5px;
            border: none;
            border-radius: 20px;
            cursor: pointer;
        }
    
    </style>
</head>

<body>
<?php
$host = "localhost";
$database = "sportsfigure_dishawar";
$username = "sportsfigure_dishawar";
$password = "sportsfigure_dishawar";
$mysqli = new mysqli($host, $username, $password, $database);
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
} else {
    // echo "Connected successfully";
}

?>

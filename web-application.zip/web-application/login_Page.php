<?php include 'comman/auth_header.php';

?>
<div style="color: black;">
  <!--<div class="profile-container">-->
  <!--  <img src="https://apk.sportsfigures.in/assets/img/logo.png" alt="Profile Logo" class="profile-logo">-->
  <!--</div>-->
  <div class="login-container">
    <h2 style="color: white;">Login</h2>

    <form id="loginForm" class="login-form" action="<?php echo 'login.php'; ?>" method="POST">
      <div class="form-group">
        <label for="mobile" style="color: white;">Phone Number</label>
       <input type="text" id="mobile" name="mobile" oninput="this.value = this.value.replace(/[^0-9]/g, ''); if (this.value.length > 10) this.value = this.value.slice(0, 10);" required style="color: white;">

      </div>
      <div class="form-group">
        <label for="password" style="color: white;">Password</label>
        <input type="password" id="password" name="password" required  style="color: white;">
      </div>
      <div>
        <h3 style="color: white; margin-left: 150px;"> <a href="forgot_page.php" style="color: white;">Forgot password?</a></h3>
      </div>
      <div class="form-group">
        <button type="submit">LOGIN NOW</button>
      </div>
      <div>
        <p style="color: white; text-align: center;">
          Don't have an Account? <a href="signup_page.php" style="color: white;"> Sign Up</a>
        </p>
      </div>
    </form>
    <div id="message"></div>
  </div>
</div>
<?php include 'comman/auth_footer.php';
?>
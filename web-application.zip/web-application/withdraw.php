
<?php include 'comman/add_fund_header.php';
?>
<div class="abc">
    <span class="back-icon" onclick="goBack()">&#8592;</span>
    <h2>withdraw Fund</h2>
</div>

<!-- for virtical card -->
<div class="container">
    <div class="card-conn">
        <div class="c" style="text-align: center" ;>
            <h3 style="color: #fff;">History</h3>
        </div>
    </div>
    <div class="amount">
        <label for="abc">Enter points</label></br>
        <input type="number" id="number" name="amount" placeholder="Enter Points" required>
    </div>

    <div class="amount">
        <input type="number" id="number" name="amount" placeholder="User payment method not added yet" required>
    </div>
    <!-- for button -->
    <button class="btn">WITHDRAW NOW</button>




    <div class="card-container">
        <div class="card">
            <h3 style=" margin-left: 20px">Anytime withdrawal minimum 1000 Rs maximum unlimited</h3>
        </div>
    </div>

    <div class="card-conn">
        <div class="card">
            <h3 style=" margin-left: 20px">Any time withdrawal wait for 10 minutes and get your money</h3>
        </div>
    </div>
    
<?php include 'comman/fund_footer.php';
?>
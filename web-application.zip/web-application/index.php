
<?php
session_start();

if (!isset($_SESSION['unique_token'])) {
    $uniqueToken = generateUniqueToken();
    $_SESSION['unique_token'] = $uniqueToken;
}

$requestedPage = isset($_GET['page']) ? $_GET['page'] : 'login_Page';
$allowedPages = ['home', 'login_Page', 'signup_page', 'forgot_page'];


if (!in_array($requestedPage, $allowedPages)) {
    $requestedPage = 'login_Page';
}


// include 'views/comman/auth_header.php';


if ($requestedPage === 'home') {
    
   
}

include  $requestedPage . '.php';
// include 'views/comman/auth_footer.php';


function generateUniqueToken()
{
    return md5(uniqid(rand(), true));
}
?>